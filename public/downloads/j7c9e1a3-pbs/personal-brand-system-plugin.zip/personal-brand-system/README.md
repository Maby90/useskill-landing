# Personal Brand System — Plugin Cowork di UseSkill.it

Il sistema completo per costruire, posizionare e vendere il tuo personal brand. 14 comandi che coprono tutto: dall'identità alla vendita, dalla strategia ai contenuti pronti da pubblicare. Ogni output esce nel tuo tono, calibrato sul tuo settore, pronto da usare.

## Cosa contiene

### Fondazione

**/identità** — Intervista strutturata in 18 domande su 4 blocchi. Estrae chi sei professionalmente, come lavori, come comunichi e dove vuoi andare. Produce la Mappa dell'Identità: il documento base su cui si costruisce tutto il resto.

**/posizionamento** — Analisi competitiva, gap di percezione, leve di differenziazione, posizionamento target. Ti dice dove sei oggi, dove dovresti essere, e come arrivarci.

**/offerta** — Architettura completa della tua offerta: scala di valore dal servizio gratuito al premium, naming dei servizi, pricing strategy, percorso del cliente dall'ingresso all'acquisto.

### Identità verbale

**/verbale** — Tagline, claim di posizionamento, vocabolario proprietario (le parole che ti definiscono), blacklist verbale (le parole vietate), 10 regole di stile precise.

**/bio** — Bio ottimizzate per LinkedIn (headline + riepilogo), Instagram, sito web (about page completa), speaker kit, firma email, elevator pitch, bio per podcast e interviste.

**/palette** — Mappa del tono di voce su 4 assi, adattamento specifico per ogni canale (LinkedIn, Instagram, newsletter, sito, email clienti, presentazioni), 3 template di contenuto (educativo, opinione, storytelling).

### Strategia

**/audit** — Analisi della tua comunicazione attuale. Fornisci i tuoi testi e ricevi: problemi specifici con citazioni, correzioni pronte da copiare, 5 quick wins da fare oggi.

**/strategia** — 3 pilastri di contenuto con 10 titoli ciascuno, format proprietario con 3 esempi scritti, anti-posizionamento, piano 90 giorni con 36 contenuti e brief per ognuno.

**/funnel** — Percorso completo in 7 fasi dalla scoperta all'acquisto. Per ogni fase: cosa succede, quali strumenti servono, quali metriche monitorare, cosa fare se non funziona.

### Vendita

**/vendita** — Script completo per la call conoscitiva (apertura, diagnosi, presentazione, obiezioni, chiusura), template preventivo pronto da compilare, sequenza follow-up in 4 messaggi, template email per 7 scenari comuni.

**/landing** — Testi completi per pagine di vendita: hero, problema, soluzione, come funziona, risultati, per chi è e per chi no, prezzo, FAQ, CTA finale. Varianti per landing lead magnet e pagine servizi.

### Produzione

**/contenuti** — Produce i contenuti scritti del piano 90 giorni. Post LinkedIn completi, caption Instagram, caroselli 10 slide, newsletter, script reel. Pronti da pubblicare.

**/riproponi** — Trasforma un contenuto esistente in 5 formati per canali diversi. Da un post LinkedIn escono storie, caroselli, script reel, spunti newsletter. Da una newsletter escono 3 post e 2 caroselli.

### Compilazione

**/playbook** — Assembla tutti i moduli completati in un unico documento: il Personal Brand Playbook. La guida di riferimento che consulti per ogni decisione.

## Il percorso consigliato

Il sistema è modulare. Puoi usare i comandi nell'ordine che vuoi. Ma se parti da zero, il percorso che dà i risultati migliori è questo:

1. **/identità** — la base di tutto
2. **/posizionamento** — dove ti collochi
3. **/offerta** — cosa vendi e come
4. **/verbale** — come parli
5. **/bio** — come ti presenti
6. **/palette** — le regole per ogni canale
7. **/strategia** — cosa comunicare e quando
8. **/funnel** — come arrivano i clienti
9. **/vendita** — come li converti
10. **/contenuti** — i contenuti pronti
11. **/playbook** — il documento finale

L'**/audit** puoi lanciarlo in qualsiasi momento: prima di iniziare (per capire dove sei) o dopo aver completato gli altri moduli (per verificare i miglioramenti).

Il **/riproponi** lo usi ogni volta che hai un contenuto e vuoi moltiplicarlo su più canali.

## Come si installa

Apri Claude Desktop e vai nella tab Cowork. In basso a sinistra trovi il menu Plugins. Clicca il "+" e scegli "Upload plugin." Seleziona la cartella personal-brand-system che hai scaricato.

Il plugin si attiva subito. Puoi iniziare a usare i comandi dal primo momento.

## Requisiti

Claude Desktop con Cowork attivo. Disponibile su tutti i piani a pagamento (Pro, Max, Team, Enterprise). Funziona su macOS e Windows.

## Supporto

Per qualsiasi problema scrivi a info@useskill.it.
