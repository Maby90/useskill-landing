# /posizionamento

Analizza il posizionamento dell'utente rispetto ai competitor e definisce il posizionamento target. Usa la skill posizionamento. Richiede che /identità sia stato completato. Se non lo è, chiedi di farlo prima.

$ARGUMENTS
