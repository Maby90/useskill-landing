# /playbook

Compila tutti i moduli completati in un unico documento: il Personal Brand Playbook. Guida di riferimento consultabile per ogni decisione di comunicazione e vendita. Usa la skill playbook.

$ARGUMENTS
