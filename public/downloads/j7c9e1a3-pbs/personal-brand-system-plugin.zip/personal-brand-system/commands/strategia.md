# /strategia

Costruisce i pilastri di contenuto, il format proprietario, l'anti-posizionamento e il piano 90 giorni con 36 contenuti. Usa la skill strategia. Richiede /identità e /posizionamento completati.

$ARGUMENTS
