# /contenuti

Produce contenuti scritti e pronti da pubblicare per una fase del piano 90 giorni. Post LinkedIn, caption Instagram, caroselli, newsletter, script reel. Usa la skill contenuti. Richiede /strategia completato.

$ARGUMENTS
