# /verbale

Costruisce l'identità verbale: tagline, claim, vocabolario proprietario, blacklist, regole di stile. Usa la skill verbale. Richiede /identità completato.

$ARGUMENTS
