# /offerta

Costruisce l'architettura dell'offerta: scala di valore, naming servizi, pricing, percorso cliente. Usa la skill offerta. Richiede /identità e /posizionamento completati.

$ARGUMENTS
