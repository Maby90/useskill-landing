# /palette

Definisce le regole di comunicazione su tutti i canali: mappa del tono, adattamento per canale, template di contenuto. Usa la skill palette. Richiede /identità e /verbale completati.

$ARGUMENTS
