# /vendita

Costruisce il sistema di vendita: script call conoscitiva, template preventivo, sequenza follow-up, template email per ogni scenario. Usa la skill vendita. Richiede /identità, /offerta e /funnel completati.

$ARGUMENTS
