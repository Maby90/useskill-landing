# /funnel

Progetta il percorso completo dalla scoperta all'acquisto: 7 fasi con strumenti, metriche e azioni concrete. Usa la skill funnel. Richiede /identità, /posizionamento e /offerta completati.

$ARGUMENTS
