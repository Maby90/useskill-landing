# /landing

Scrive i testi completi per pagine di vendita, pagine servizi o landing page per lead magnet. Ogni sezione dall'hero al footer. Usa la skill landing. Richiede /identità e /offerta completati.

$ARGUMENTS
