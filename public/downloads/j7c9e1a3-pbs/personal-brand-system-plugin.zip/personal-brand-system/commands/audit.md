# /audit

Analizza la comunicazione attuale dell'utente. L'utente fornisce i suoi testi (post, bio, newsletter, email, preventivi). Produci un report con problemi, correzioni pronte e quick wins. Usa la skill audit.

$ARGUMENTS
