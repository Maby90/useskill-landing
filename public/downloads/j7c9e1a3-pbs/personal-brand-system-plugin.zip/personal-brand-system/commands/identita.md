# /identità

Avvia l'intervista di estrazione dell'identità. Usa la skill identita per la struttura e le regole. Fai le domande un blocco alla volta. Non procedere al blocco successivo senza risposte complete.

$ARGUMENTS
