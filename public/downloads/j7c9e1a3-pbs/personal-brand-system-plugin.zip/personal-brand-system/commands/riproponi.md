# /riproponi

Prende un contenuto esistente e lo trasforma in più formati per canali diversi. Un post diventa 5 contenuti. Una newsletter diventa 3 post e 2 caroselli. Usa la skill riproponi.

$ARGUMENTS
