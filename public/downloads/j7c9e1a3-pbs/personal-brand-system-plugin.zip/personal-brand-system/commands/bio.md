# /bio

Genera bio ottimizzate per ogni piattaforma: LinkedIn headline e riepilogo, Instagram, sito web, speaker kit, firma email, elevator pitch, bio podcast. Usa la skill bio. Richiede /identità e /verbale completati.

$ARGUMENTS
