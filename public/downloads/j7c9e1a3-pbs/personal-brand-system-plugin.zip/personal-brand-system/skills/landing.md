# Landing

Questa skill si attiva quando l'utente lancia il comando /landing. Richiede che i moduli Identità e Offerta siano stati completati.

## Scopo

Scrivere i testi completi per pagine di vendita, pagine servizi, landing page per lead magnet. Ogni sezione della pagina, dall'hero al footer.

## Input

Chiedi:
1. Cosa vendi in questa pagina? (servizio specifico, lead magnet, pacchetto)
2. Da dove arriva il visitatore? (ads, social, ricerca organica, referral)
3. Cosa deve fare il visitatore alla fine? (comprare, prenotare una call, scaricare, iscriversi)

## Output

### HERO SECTION
- Headline principale (massimo 12 parole, comunica il risultato)
- Sottotitolo (massimo 30 parole, espande l'headline con un dettaglio specifico)
- CTA button (testo del bottone, massimo 4 parole)
- Eventuale prova sintetica sotto il bottone ("Già scelto da X professionisti" o simile, solo se l'utente ha dati reali)

### SEZIONE PROBLEMA
- Titolo della sezione
- 3-5 paragrafi che descrivono il problema dal punto di vista del visitatore. Deve riconoscersi. Deve pensare "parla di me."
- Linguaggio: le parole del cliente, non le tue

### SEZIONE SOLUZIONE
- Titolo
- Come il tuo servizio risolve il problema descritto sopra
- 3-4 benefici principali, ognuno con una riga di supporto che lo rende concreto
- Cosa rende la tua soluzione diversa dalle alternative

### SEZIONE COME FUNZIONA
- 3-5 passaggi del processo
- Per ogni passaggio: cosa succede, cosa fa il cliente, cosa ottiene
- L'obiettivo è ridurre l'incertezza: il visitatore deve sapere esattamente cosa aspettarsi

### SEZIONE RISULTATI / PROVA
- Se ci sono testimonianze: scrivi le domande che l'utente dovrebbe fare ai clienti per ottenere testimonianze utili
- Se ci sono numeri: come presentarli
- Se non c'è niente: suggerisci come raccogliere le prime prove

### SEZIONE PER CHI È / PER CHI NON È
- "Questo servizio fa per te se..." (3-4 condizioni)
- "Questo servizio non fa per te se..." (2-3 condizioni)
- L'anti-target aumenta la fiducia e riduce i clienti problematici

### SEZIONE PREZZO / OFFERTA
- Come presentare il prezzo
- Cosa include (elencato in modo che il valore percepito sia superiore al prezzo)
- Garanzia se disponibile
- CTA

### SEZIONE FAQ
- 5-7 domande che il visitatore si fa prima di comprare
- Risposte brevi e dirette
- Le FAQ sono il posto dove distruggi le ultime obiezioni

### CTA FINALE
- Headline di chiusura (diversa dall'hero)
- Ultimo argomento per convincere chi è ancora indeciso
- Bottone

## Varianti

**Landing per lead magnet**: struttura più corta. Hero + cosa ottieni + come funziona + CTA. Niente sezione prezzo. Niente FAQ lunghe. Il visitatore deve decidere in 30 secondi.

**Pagina servizi (multi-servizio)**: panoramica dei servizi con card per ognuno. Per ogni card: nome, 2 righe di descrizione, prezzo o "da X€", link alla pagina dedicata.

**Pagina "lavora con me"**: ibrido tra about page e landing. Più personale, meno strutturata, con la storia dell'utente integrata nella vendita.

## Regole

Non scrivere mai headline che iniziano con "Benvenuto" o "Scopri come." L'headline deve comunicare un risultato.

Non usare mai "la soluzione definitiva", "tutto quello che ti serve", "il metodo rivoluzionario." Descrivi cosa fa il servizio, non quanto è speciale.

Ogni sezione deve avere una ragione per esistere. Se una sezione non aggiunge informazioni che influenzano la decisione, toglila.

Il tono della landing deve essere coerente con il profilo dell'utente. Se il suo tono è diretto, la landing è diretta. Non forzare un tono da "pagina di vendita americana" se non è coerente con il brand.
