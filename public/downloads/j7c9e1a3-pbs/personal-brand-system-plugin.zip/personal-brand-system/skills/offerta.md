# Offerta

Questa skill si attiva quando l'utente lancia il comando /offerta. Richiede che i moduli Identità e Posizionamento siano stati completati.

## Scopo

Costruire l'architettura completa dell'offerta dell'utente: packaging dei servizi, naming, pricing, scala di valore, e il percorso che un cliente fa dal primo contatto all'acquisto del servizio premium.

## Input richiesto

Chiedi all'utente:

1. Quali servizi offri oggi? Elencali tutti, anche quelli che fai raramente. Per ognuno: cosa include, quanto costa, quanto tempo ci metti, quanto margine hai.
2. C'è un servizio che vorresti vendere di più? Quale e perché?
3. C'è un servizio che vorresti smettere di vendere? Quale e perché?
4. Come vendi attualmente? (call conoscitiva, preventivo via email, incontro di persona, landing page, altro)
5. Qual è il tuo cliente più redditizio degli ultimi 12 mesi? Cosa ha comprato, quanto ha pagato, come è arrivato a te.
6. Qual è il cliente che ti ha dato più problemi? Cosa è andato storto?
7. Se potessi avere 10 clienti identici, come sarebbero? Cosa comprerebbero? Quanto pagherebbero?

## Output

### ANALISI DELL'OFFERTA ATTUALE

Per ogni servizio elencato, valuta:
- Il nome comunica il valore o è generico?
- Il prezzo è coerente con il posizionamento target?
- Il servizio attrae il cliente ideale o quello sbagliato?
- Il margine giustifica il tempo investito?

Classifica ogni servizio in una di queste categorie:
- **Tenere e valorizzare**: il servizio funziona, va comunicato meglio
- **Ristrutturare**: il servizio ha potenziale ma il packaging, il prezzo o il target vanno cambiati
- **Eliminare**: il servizio non è coerente con il posizionamento target o non è redditizio

### SCALA DI VALORE

Progetta la scala di valore completa dell'utente. Ogni gradino deve avere un nome, un prezzo, un contenuto e un obiettivo strategico.

**Gradino 0 — Punto di ingresso gratuito**
Come il potenziale cliente ti scopre e ottiene un primo valore senza pagare. Può essere un contenuto, una risorsa scaricabile, un mini-servizio, una consulenza di 15 minuti. Deve:
- Dimostrare competenza
- Risolvere un micro-problema reale
- Creare il desiderio del passo successivo
Proponi 2-3 opzioni con pro e contro di ognuna.

**Gradino 1 — Servizio di ingresso (low-ticket)**
Il primo acquisto. Prezzo basso, rischio percepito minimo, risultato tangibile. Serve a trasformare il contatto in cliente pagante e a validare la relazione.
- Nome del servizio
- Cosa include (deliverable specifici)
- Prezzo suggerito con motivazione
- Tempo di erogazione
- Come si vende (processo)

**Gradino 2 — Servizio principale (mid-ticket)**
Il servizio che genera la maggior parte del fatturato. Deve essere il più forte dell'offerta: risultato chiaro, processo definito, prezzo sostenibile per il target.
- Nome del servizio
- Cosa include (deliverable specifici con dettaglio)
- Prezzo suggerito con motivazione
- Durata del progetto
- Come si vende
- Garanzia o clausola di soddisfazione suggerita

**Gradino 3 — Servizio premium (high-ticket)**
Il servizio per i clienti migliori. Più personalizzato, più lungo, più costoso. Pochi clienti, alto valore.
- Nome del servizio
- Cosa include
- Prezzo suggerito
- Come si qualificano i candidati (non tutti possono accedere)
- Processo di vendita specifico per high-ticket

**Gradino 4 — Continuità (retainer/abbonamento)**
Se applicabile. Un modo per continuare a lavorare con i clienti dopo il progetto. Può essere consulenza mensile, supporto continuativo, accesso a risorse aggiornate.

### NAMING DEI SERVIZI

Per ogni servizio nella scala di valore, proponi 2-3 nomi. Ogni nome deve:
- Comunicare il risultato, non il processo
- Essere memorabile
- Non contenere gergo tecnico del settore
- Distinguersi dai nomi che usano i competitor

Esempio di cosa evitare: "Pacchetto Consulenza Base", "Servizio Premium Plus", "Audit Strategico."
Esempio di cosa funziona: dipende dal settore, ma il nome deve suggerire cosa ottiene il cliente.

### PRICING STRATEGY

Per ogni servizio:
- Prezzo suggerito
- Come comunicare il prezzo (sulla pagina, in call, nel preventivo)
- Quando e come fare sconti (se mai)
- Come gestire la trattativa sul prezzo
- Confronto con i prezzi dei competitor (se noti)

### PERCORSO DEL CLIENTE

Descrivi il percorso completo che un potenziale cliente fa dal primo contatto all'acquisto del servizio premium:
1. Come ti scopre
2. Primo valore gratuito che riceve
3. Come si trasforma in lead
4. Come si qualifica
5. Come acquista il primo servizio
6. Come sale nella scala di valore
7. Come diventa cliente ricorrente
8. Come ti porta altri clienti

Per ogni passaggio, indica cosa succede concretamente e quali strumenti o contenuti servono.

## Regole

Non inventare prezzi dal nulla. Basati sul settore dell'utente, sul suo posizionamento target, e sul prezzo attuale. Se suggerisci di alzare un prezzo, spiega cosa deve cambiare nel packaging per giustificarlo.

Non proporre scale di valore con 7 servizi. Massimo 4-5 gradini. La semplicità vende.

I nomi dei servizi non devono suonare come quelli di una web agency americana. Devono funzionare nel contesto italiano e nel settore specifico dell'utente.

Se l'utente vende servizi professionali (consulenza, coaching, freelancing), non suggerire mai prodotti digitali scalabili (corsi, membership) a meno che non lo chieda esplicitamente. Il focus è sul business attuale.
