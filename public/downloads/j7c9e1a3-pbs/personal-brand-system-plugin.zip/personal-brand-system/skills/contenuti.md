# Contenuti

Questa skill si attiva quando l'utente lancia il comando /contenuti. Richiede che il modulo Strategia sia stato completato.

## Scopo

Trasformare il piano strategico in contenuti scritti e pronti da pubblicare. Non titoli e brief. Contenuti finiti.

## Input

Chiedi all'utente:
1. Per quale fase del piano 90 giorni vuoi i contenuti? (Fase 1, 2 o 3)
2. Per quale canale? (LinkedIn, Instagram, newsletter, tutti)
3. Hai il profilo del tono di voce? Se sì, incollalo. Se no, fornisci 3 testi scritti da te.

## Output

Per ogni contenuto del piano, produci il testo completo pronto da pubblicare.

### FORMATO POST LINKEDIN
- Hook (prima riga, quella che si vede prima di "altro")
- Corpo (sviluppo, 150-300 parole)
- Chiusura con CTA
- 3-5 hashtag

### FORMATO CAPTION INSTAGRAM
- Hook (prima riga)
- Corpo (100-200 parole)
- CTA
- 15-20 hashtag divisi in: 5 di settore, 5 di nicchia, 5-10 di reach

### FORMATO CAROSELLO INSTAGRAM
- 10 slide con il testo esatto per ogni slide
- Note sul visual consigliato per ogni slide
- Caption di accompagnamento

### FORMATO NEWSLETTER
- Oggetto
- Preview text
- Apertura
- Corpo (300-500 parole)
- CTA

### FORMATO REEL / SHORT
- Script parlato (60 secondi)
- Note su inquadratura e ritmo
- Testo a schermo per ogni scena
- Caption
- Hashtag

## Modalità batch

Se l'utente chiede i contenuti per un'intera fase (12 contenuti), producili tutti. Numera ogni contenuto e indica la data di pubblicazione consigliata, il canale e il pilastro di riferimento.

Se il volume è troppo per un singolo output, dividi in blocchi da 4 e chiedi all'utente di dire "continua" per il blocco successivo.

## Regole

Ogni contenuto deve essere diverso dagli altri. Non riciclare strutture, hook o chiusure.

I contenuti devono rispettare il vocabolario proprietario e la blacklist del modulo Sistema Verbale.

Non scrivere mai contenuti che iniziano con "In un mondo sempre più..." o qualsiasi variante.

Non usare mai triadi di aggettivi. Non usare mai elenchi paralleli troppo perfetti. Non usare mai domande retoriche in chiusura come "E tu, cosa ne pensi?"

Ogni contenuto deve superare il test: "Questo testo potrebbe averlo scritto l'utente di suo pugno?" Se la risposta è no, riscrivilo.
