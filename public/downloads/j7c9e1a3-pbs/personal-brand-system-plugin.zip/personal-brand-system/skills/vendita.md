# Vendita

Questa skill si attiva quando l'utente lancia il comando /vendita. Richiede che i moduli Identità, Offerta e Funnel siano stati completati.

## Scopo

Costruire il sistema di vendita completo: script per le call, template per i preventivi, sequenza di follow-up, gestione delle obiezioni.

## Output

### SCRIPT CALL CONOSCITIVA

Struttura completa della prima call con un potenziale cliente. Non un copione da leggere parola per parola. Una struttura con le domande giuste nell'ordine giusto e le transizioni tra le fasi.

**Apertura (2 minuti)**
- Come rompere il ghiaccio senza perdere tempo
- Come stabilire che sei tu a guidare la conversazione
- La frase che imposta le aspettative: "In questa chiamata farò [X], tu mi racconterai [Y], e alla fine vediamo se ha senso lavorare insieme."

**Diagnosi (10 minuti)**
- 5-7 domande per capire la situazione del cliente
- Per ogni domanda: cosa stai cercando di capire e come la risposta influenza la proposta
- Come approfondire le risposte vaghe
- I segnali che indicano che il cliente è giusto per te
- I segnali che indicano che non lo è (e come gestire la cosa con eleganza)

**Presentazione della soluzione (5 minuti)**
- Come collegare i problemi emersi alla tua soluzione specifica
- Come presentare il servizio senza farlo sembrare un pitch
- Le 3 frasi che comunicano il valore meglio di qualsiasi elenco di deliverable
- Come introdurre il prezzo senza esitare

**Gestione obiezioni (5 minuti)**
Le 7 obiezioni più comuni nel settore dell'utente. Per ognuna:
- L'obiezione esatta come la formula il cliente
- Perché la fa (il dubbio reale sotto l'obiezione)
- La risposta che funziona (non aggressiva, non difensiva)
- Come verificare se l'obiezione è risolta

**Chiusura (3 minuti)**
- Come chiedere la decisione senza sembrare aggressivo
- Cosa dire se dice sì
- Cosa dire se dice "ci penso" (e la sequenza di follow-up che parte)
- Cosa dire se dice no (e come chiudere il rapporto con classe)

### TEMPLATE PREVENTIVO / PROPOSTA

Struttura del documento commerciale. Non un elenco di servizi con i prezzi. Un documento che vende.

**Sezione 1 — Il contesto**
Riepilogo della situazione del cliente come l'ha raccontata in call. Il cliente deve leggere e pensare "sì, è esattamente così." 3-5 righe.

**Sezione 2 — L'obiettivo**
Cosa vuole ottenere il cliente. Scritto con le sue parole, non con le tue. 2-3 righe.

**Sezione 3 — La soluzione proposta**
Il servizio, descritto in termini di risultato. Non "audit del sito web" ma "analisi delle 5 pagine che influenzano la decisione del tuo cliente, con le correzioni pronte da applicare."
Per ogni deliverable: cosa ottiene il cliente e entro quando.

**Sezione 4 — Come lavoriamo**
Il processo step by step. Cosa succede dopo che il cliente accetta. Tempistiche chiare.

**Sezione 5 — Investimento**
Il prezzo. Senza scuse, senza giustificazioni eccessive. Il prezzo, cosa include, eventuali opzioni di pagamento. Se ci sono pacchetti diversi, massimo 2-3 opzioni.

**Sezione 6 — Prossimi passi**
Cosa deve fare il cliente per partire. Una sola azione chiara.

**Sezione 7 — Garanzia (opzionale)**
Se l'utente offre garanzie, descrivile qui.

Scrivi un template completo con placeholder dove l'utente inserisce i dati del cliente. Il template deve essere pronto da compilare in 10 minuti.

### SEQUENZA FOLLOW-UP

Cosa mandare dopo la call se il cliente non decide subito.

**Messaggio 1 — Giorno 0 (dopo la call)**
Riepilogo della conversazione. Allegato il preventivo. Tono professionale, zero pressione.

**Messaggio 2 — Giorno 3**
Un contenuto di valore legato al problema del cliente (un articolo, un caso studio, un consiglio). Nessuna menzione del preventivo.

**Messaggio 3 — Giorno 7**
Check-in breve. "Hai avuto modo di leggere la proposta? Sono a disposizione se hai domande."

**Messaggio 4 — Giorno 14**
Messaggio di chiusura. "Capisco che i tempi possano non essere giusti. Se cambia qualcosa, sai dove trovarmi." Chiudi con dignità.

Per ogni messaggio: testo completo pronto da copiare (con placeholder per nome e dettagli).

### TEMPLATE EMAIL PER SCENARI COMUNI

Scrivi un template per ognuno di questi scenari:
- Primo contatto a freddo (qualcuno ti scrive chiedendo informazioni)
- Risposta a "quanto costi?"
- Invio del preventivo
- Il cliente chiede uno sconto
- Il cliente sparisce dopo il preventivo
- Il cliente dice sì
- Il progetto è finito, chiedi una recensione

Ogni template: oggetto + testo completo, pronto da personalizzare in 2 minuti.

## Regole

Gli script non devono suonare come quelli di un venditore americano. Devono suonare come una conversazione tra professionisti in Italia.

I preventivi non devono sembrare documenti legali. Devono essere leggibili, chiari, e far venire voglia di dire sì.

La sequenza di follow-up non deve essere aggressiva. Dopo il quarto messaggio, basta. Insistere oltre comunica disperazione.

I template email devono rispettare il tono dell'utente. Se il suo tono è diretto, le email sono dirette. Se è più morbido, le email sono morbide. Adatta tutto al profilo.
