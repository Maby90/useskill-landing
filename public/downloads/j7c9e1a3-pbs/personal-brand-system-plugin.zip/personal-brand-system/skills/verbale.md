# Sistema Verbale

Questa skill si attiva quando l'utente lancia il comando /verbale. Richiede che il Modulo Identità sia stato completato.

## Scopo

Costruire l'intera identità verbale del brand: tagline, claim, vocabolario proprietario, blacklist, regole di stile.

## Output

### TAGLINE

3 proposte. Ogni tagline deve essere:
- Massimo 6 parole
- Comprensibile senza contesto
- Impossibile da attribuire a un competitor
- Priva di parole generiche (innovazione, eccellenza, qualità, passione, soluzioni)

Per ogni proposta: perché funziona e dove usarla (bio, firma email, header sito, slide di apertura).

### CLAIM DI POSIZIONAMENTO

15-20 parole che comunicano il valore dell'utente a chi non lo conosce. La risposta a "cosa fai?" che genera la domanda successiva. Non è uno slogan. È una dichiarazione precisa.

3 proposte con contesto d'uso per ognuna.

### VOCABOLARIO PROPRIETARIO

15-20 parole o espressioni che l'utente dovrebbe usare in tutta la comunicazione. Per ogni parola:
- La parola o espressione
- Perché è coerente con il brand
- In quale contesto usarla (post, call, preventivo, bio)
- La parola generica che sostituisce

### BLACKLIST VERBALE

15 parole o espressioni vietate. Per ognuna:
- La parola
- Perché è dannosa per il brand (generica, abusata, non coerente con il posizionamento)
- L'alternativa concreta

### REGOLE DI STILE

10 regole precise. Ognuna con un esempio di cosa fare e cosa non fare:
- Lunghezza media delle frasi
- Uso o non uso di domande retoriche
- Uso o non uso di emoji
- Come aprire un contenuto (le prime parole)
- Come chiudere un contenuto
- Come formulare le call to action
- Punteggiatura (esclamativi, puntini di sospensione, virgolette)
- Formattazione (grassetto, maiuscole, elenchi)
- Parole straniere: quando usarle e quando no
- Come parlare di sé (prima persona, terza persona, quando alternare)

## Regole

Ogni proposta deve essere specifica per quella persona. Se una tagline potrebbe funzionare per chiunque nel settore, non è abbastanza specifica.

Il vocabolario proprietario non è una lista di sinonimi eleganti. Sono le parole che costruiscono l'identità verbale dell'utente nel tempo. Devono essere naturali per il suo modo di comunicare, non forzate.

La blacklist non è una lista generica di "parole da evitare nel marketing." È specifica per il settore e il posizionamento dell'utente.
