# Audit

Questa skill si attiva quando l'utente lancia il comando /audit.

## Scopo

Analizzare la comunicazione attuale dell'utente e produrre un report con i problemi specifici, le correzioni e i quick wins.

## Input richiesto

Chiedi all'utente di fornirti tutto il materiale che ha:
- Gli ultimi 5-10 post pubblicati (LinkedIn, Instagram o entrambi)
- La bio attuale su ogni piattaforma
- L'eventuale pagina "chi sono" del sito
- L'ultima newsletter inviata (se ne ha una)
- Un'email tipo che manda ai clienti
- Il preventivo o la proposta commerciale che usa

Analizza tutto il materiale e produci:

## Output

### COERENZA DEL BRAND
Il brand comunica un messaggio coerente su tutti i canali? Dove si contraddice? Dove è vago? Dove dice una cosa su LinkedIn e un'altra su Instagram?

### EFFICACIA DEL POSIZIONAMENTO
Dopo aver letto tutti i contenuti, un estraneo capirebbe cosa fa l'utente, per chi e perché sceglierlo? Se no, dove si perde il messaggio? Sii specifico: cita le frasi problematiche e spiega cosa non funziona.

### ANALISI DEL TONO
Il tono è coerente tra i canali? Ci sono disallineamenti? Il tono riflette la personalità emersa dal Modulo Identità (se completato)?

### TOP 5 PROBLEMI
I 5 problemi più gravi nella comunicazione attuale, in ordine di impatto. Per ognuno:
- Cosa c'è di sbagliato (con citazione del testo problematico)
- Perché è un problema (quale impatto ha sulla percezione, sulla conversione, sulla fiducia)
- Come correggerlo: il testo riscritto, pronto da usare

### QUICK WINS
5 correzioni che l'utente può fare oggi, ognuna in meno di 15 minuti:
- Cosa cambiare
- Dove cambiarlo
- Il testo nuovo da mettere al posto di quello vecchio

### PRIORITÀ
Dopo l'audit, indica le 3 azioni con il maggiore impatto in ordine di priorità. Per ognuna, stima il tempo necessario e il risultato atteso.

## Regole

Sii diretto. Se un testo è debole, dillo. Ma proponi sempre la correzione insieme alla critica.

Non fare l'audit di cose che non hai visto. Se l'utente non ti dà la newsletter, non commentare la newsletter.

Le correzioni devono essere pronte da copiare e incollare. Non "potresti riscrivere la bio in modo più incisivo." Ma "ecco la bio riscritta: [testo]."
