# Palette Comunicativa

Questa skill si attiva quando l'utente lancia il comando /palette. Richiede che i moduli Identità e Sistema Verbale siano stati completati.

## Scopo

Definire le regole di comunicazione del brand su tutti i canali. Il documento che esce diventa il riferimento per ogni contenuto futuro.

## Output

### TONO DI VOCE — MAPPA

Descrivi il tono su 4 assi, con un valore da 1 a 10:
- Formale ←→ Informale
- Serio ←→ Ironico
- Tecnico ←→ Divulgativo
- Distaccato ←→ Personale

Per ogni asse: cosa significa quel valore nella pratica. Esempio: "7/10 sull'asse Informale significa che usi il tu, fai riferimenti alla vita quotidiana, ma non scadi mai nel colloquiale. Non scrivi 'roba' o 'figata' ma nemmeno 'si evince che' o 'è doveroso precisare.'"

### ADATTAMENTO PER CANALE

Per ogni canale, descrivi cosa cambia e cosa resta uguale:

**LinkedIn**: registro, lunghezza, strutture preferite per l'apertura, come chiudere, frequenza. Un esempio di apertura e chiusura.

**Instagram post**: registro, lunghezza caption, uso hashtag, uso emoji, tono visivo dei testi. Un esempio di caption completa.

**Instagram stories**: tono, lunghezza testo su schermo, frequenza, tipo di contenuto. Un esempio.

**Newsletter**: registro, lunghezza, struttura (oggetto, apertura, corpo, CTA), frequenza. Un esempio di apertura.

**Sito web**: registro per le pagine statiche (home, servizi, about, contatto). Come cambia rispetto ai social.

**Email ai clienti**: registro per comunicazioni dirette (preventivi, aggiornamenti, follow-up). Un esempio.

**Presentazioni dal vivo / webinar**: come cambia il tono rispetto allo scritto. Cosa mantenere, cosa adattare.

### TEMPLATE DI CONTENUTO

3 strutture ricorrenti:

**Template educativo**: per contenuti che insegnano qualcosa. Schema con sezioni, esempio compilato, 3 variazioni possibili.

**Template di opinione**: per contenuti dove prendi posizione. Schema, esempio compilato, come gestire le reazioni negative.

**Template storytelling**: per contenuti personali. Schema, esempio compilato, come dosare il personale senza diventare un diario.

Per ogni template: dove funziona meglio (quale canale) e con che frequenza usarlo.

## Regole

I template non devono diventare gabbie. Sono punti di partenza, non formule. Devono avere abbastanza struttura da essere utili ma abbastanza flessibilità da non rendere i contenuti ripetitivi.

L'adattamento per canale non è "su Instagram sii più casual." È un documento operativo con indicazioni precise che qualcuno può seguire senza interpretare.
