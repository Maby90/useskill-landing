# Riproponi

Questa skill si attiva quando l'utente lancia il comando /riproponi.

## Scopo

Prendere un contenuto esistente e trasformarlo in più formati per canali diversi. Un contenuto diventa cinque senza pensare da zero ogni volta.

## Input

L'utente incolla un contenuto (post, newsletter, articolo, trascrizione video, appunti) e indica il canale di origine. Tu produci le versioni per tutti gli altri canali.

## Trasformazioni

### Da post LinkedIn →
- 3 storie Instagram (testo per ogni story, tono adattato)
- 1 caption Instagram con hook diverso dall'originale
- 1 script reel/short di 60 secondi
- 1 spunto per newsletter (angolo diverso sullo stesso tema)
- 1 thread di 5 tweet/post brevi

### Da newsletter →
- 3 post LinkedIn (ognuno prende un angolo diverso dalla newsletter)
- 2 caroselli Instagram (ognuno sviluppa un punto specifico)
- 1 script reel/short
- 3 storie Instagram

### Da articolo blog →
- 5 post LinkedIn (uno per ogni sezione dell'articolo)
- 3 caroselli Instagram
- 1 newsletter che riassume e aggiunge un punto di vista personale
- 2 script reel/short
- 5 storie Instagram

### Da trascrizione video →
- 3 post LinkedIn con le citazioni migliori contestualizzate
- 1 newsletter
- 2 caroselli Instagram
- 5 clip testuali per storie

### Da appunti / idee grezze →
- 1 post LinkedIn completo
- 1 carosello Instagram
- 1 script reel/short
- 3 storie Instagram

## Regole

Ogni versione deve sembrare un contenuto nativo del canale, non un copia-incolla adattato. Il post LinkedIn che diventa caption Instagram deve cambiare struttura, lunghezza, tono.

Non ripetere lo stesso hook su canali diversi. Se il post originale apre con una domanda, la versione Instagram può aprire con un'affermazione, e il reel con uno scenario.

Ogni versione deve aggiungere qualcosa o cambiare angolo. Non basta accorciare o allungare.

Se il tono di voce dell'utente è nel contesto, applicalo a tutte le versioni. Se non c'è, mantieni il tono del contenuto originale.
