# Playbook

Questa skill si attiva quando l'utente lancia il comando /playbook.

## Scopo

Compilare tutti i moduli completati in un unico documento di riferimento: il Personal Brand Playbook. Questo è il documento che l'utente consulta per ogni decisione di comunicazione, vendita e posizionamento.

## Come funziona

Chiedi all'utente quali moduli ha completato. Compila solo le sezioni per cui esistono gli output. Non inventare le sezioni mancanti.

## Struttura del Playbook

### 1. IDENTITÀ
Dalla Mappa dell'Identità: chi sei, il problema che risolvi, il differenziale, il metodo, le anti-regole, l'opinione forte, il tono naturale, la direzione, la storia di origine.

### 2. POSIZIONAMENTO
Mappa competitiva, gap di percezione, leve di differenziazione, rischi, posizionamento target, arena.

### 3. OFFERTA
Scala di valore completa con tutti i gradini. Naming dei servizi. Pricing strategy. Percorso del cliente.

### 4. SISTEMA VERBALE
Tagline, claim, vocabolario proprietario, blacklist, regole di stile.

### 5. BIO
Tutte le bio per ogni piattaforma. Elevator pitch. Bio speaker. Bio firma email.

### 6. PALETTE COMUNICATIVA
Mappa del tono, adattamento per canale, template di contenuto.

### 7. STRATEGIA
Pilastri di contenuto, format proprietario, anti-posizionamento, piano 90 giorni.

### 8. FUNNEL
Mappa del funnel per fase. Strumenti necessari. Metriche.

### 9. SISTEMA DI VENDITA
Script call. Template preventivo. Sequenza follow-up. Template email.

### 10. AUDIT (se completato)
Problemi identificati, correzioni, quick wins, priorità.

## Formato

Il playbook deve essere organizzato come guida di riferimento consultabile. Ogni sezione è autonoma: l'utente deve poterla rileggere tra 6 mesi e trovare tutto senza dover rifare il percorso.

Usa titoli chiari. Niente introduzioni o premesse. Vai dritto al contenuto.

Alla fine del playbook, aggiungi una sezione "PROSSIMI PASSI" con le 5 azioni prioritarie da fare questa settimana, ordinate per impatto.

## Regole

Non aggiungere sezioni che non sono state completate. Se manca il modulo Vendita, il playbook non ha la sezione vendita. Segnala quali moduli mancano e suggerisci di completarli.

Non riformulare gli output dei moduli. Riportali come sono stati prodotti. Il playbook è una raccolta, non una riscrittura.

L'unica cosa che aggiungi sono i collegamenti tra le sezioni: dove un pezzo informa l'altro, segnalalo con una nota breve.
