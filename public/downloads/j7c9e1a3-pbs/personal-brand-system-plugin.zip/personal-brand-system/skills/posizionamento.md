# Posizionamento

Questa skill si attiva quando l'utente lancia il comando /posizionamento. Richiede che il Modulo Identità (/identità) sia stato completato. Se non lo è, chiedi all'utente di completarlo prima.

## Scopo

Analizzare il posizionamento attuale dell'utente, identificare i gap tra percezione attuale e desiderata, definire il posizionamento target e le leve di differenziazione.

## Input richiesto

Chiedi all'utente:

1. Elencami 3-5 professionisti nel tuo settore che consideri competitor diretti o indiretti. Per ognuno dimmi: cosa fanno, cosa fanno bene, cosa fanno male secondo te, come comunicano.
2. Mostrami i tuoi attuali profili social e sito (copia i testi delle bio, delle pagine "chi sono", dei post più recenti). Se non li hai, dimmelo.
3. Come ti trovano i clienti attualmente? Passaparola, social, ricerca Google, eventi, altro?
4. Qual è il prezzo medio dei tuoi servizi? Come lo percepisci rispetto al mercato?
5. Se chiedessi ai tuoi ultimi 5 clienti perché ti hanno scelto, cosa direbbero?

## Analisi

Sulla base delle risposte e della Mappa dell'Identità, produci:

**MAPPA COMPETITIVA**
Posiziona l'utente e i competitor su 2 assi che scegli tu in base al settore. Gli assi devono essere rilevanti per la differenziazione (non generici come "prezzo/qualità"). Esempi: specializzazione/generalismo, visibilità/autorevolezza, approccio consulenziale/approccio operativo, presenza online/presenza offline. Spiega perché hai scelto quegli assi. Descrivi la posizione di ognuno con 2 righe.

**GAP DI PERCEZIONE**
La differenza tra come l'utente vuole essere percepito (dalla Mappa dell'Identità) e come viene percepito oggi (dai testi attuali e dalle risposte). Sii specifico: "Vuoi essere percepito come specialista ma i tuoi testi parlano di 12 servizi diversi" non "c'è un leggero disallineamento."

**3 LEVE DI DIFFERENZIAZIONE**
Le 3 cose concrete su cui l'utente può costruire un posizionamento impossibile da copiare. Per ogni leva:
- Cosa è
- Perché funziona nel suo settore specifico
- Come attivarla nella comunicazione (con un esempio concreto di messaggio)
- Cosa succede se non la usa

**RISCHI**
Le 2-3 cose che rischiano di rendere invisibile o interscambiabile il brand se non vengono corrette. Per ogni rischio, spiega cosa sta succedendo e l'impatto concreto.

**POSIZIONAMENTO TARGET**
Una frase nella forma: "[Nome] è il/la [ruolo specifico] che [cosa fa di diverso] per [chi, descritto con precisione] che [problema specifico del target]."

Questa frase deve essere impossibile da attribuire a chiunque altro nel settore. Se funzionerebbe per un competitor, non è abbastanza specifica. Riscrivila.

**LA TUA ARENA**
Il settore ridefinito in modo stretto. Non "marketing digitale." Ma "comunicazione per architetti freelance che vendono ristrutturazioni sopra i 50.000€." Più l'arena è stretta, più è facile dominarla. Spiega perché quest'arena è quella giusta.

## Regole

Non inventare competitor. Lavora solo con quelli forniti dall'utente. Se ne servono di più, chiedi.

Non dare consigli generici come "dovresti differenziarti." Ogni indicazione deve essere specifica e attuabile questa settimana.

Se i testi attuali dell'utente sono deboli, dillo con chiarezza. Non addolcire. Ma proponi la correzione insieme alla critica.
