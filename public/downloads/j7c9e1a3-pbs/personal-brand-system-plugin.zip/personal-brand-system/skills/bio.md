# Bio

Questa skill si attiva quando l'utente lancia il comando /bio. Richiede che i moduli Identità e Sistema Verbale siano stati completati.

## Scopo

Generare bio ottimizzate per ogni piattaforma, coerenti con l'identità e il posizionamento. Ogni bio è diversa nel formato e nel taglio, ma coerente nel messaggio e nel tono. Non sono la stessa bio accorciata o allungata.

## Output

### BIO LINKEDIN — HEADLINE
Massimo 220 caratteri. Comunica cosa fai e per chi. Niente emoji. Niente titoli generici ("CEO & Founder | Appassionato di..."). Deve far venire voglia di cliccare sul profilo.

### BIO LINKEDIN — RIEPILOGO
300-500 parole. Struttura:
- Apertura con un'affermazione forte o un'esperienza concreta. Mai iniziare con "Sono un professionista con X anni di esperienza." Mai iniziare con "Mi chiamo."
- Il problema che risolvi, raccontato come lo vive il cliente
- Il tuo approccio e cosa fai diversamente
- Un risultato concreto o una prova
- Chiusura con invito all'azione specifico (non "contattami per saperne di più")

### BIO INSTAGRAM
Massimo 150 caratteri. Una riga che dice cosa fai, una che dice per chi, una call to action. Se usi emoji, solo funzionali (freccia per il link). Niente emoji motivazionali (razzi, stelle, fuoco).

### BIO SITO WEB — ABOUT PAGE
500-800 parole. Prima persona. Struttura:
- Apertura con la tua opinione forte o il tuo punto di vista sul settore
- La storia che ti ha portato a fare quello che fai (non cronologia, racconto con punto di svolta, dalla Mappa dell'Identità)
- Il tuo metodo e perché funziona
- Per chi lavori e per chi non lavori (l'anti-target è potente quanto il target)
- Chiusura con la tua visione e invito a lavorare insieme

### BIO SPEAKER / CONFERENZE
100-150 parole. Terza persona. Professionale, concreta, con risultati specifici. Niente "è un esperto di..."

### BIO FIRMA EMAIL
2 righe. La versione più compressa dell'identità professionale. Deve stare sotto un nome e un numero di telefono senza occupare troppo spazio.

### ELEVATOR PITCH
75-80 parole (30 secondi parlati). Quello che dici quando qualcuno ti chiede "ma tu cosa fai?" Deve suonare naturale, non recitato. Deve generare la risposta "interessante, raccontami di più" non "ah ok."

### PRESENTAZIONE PER PODCAST / INTERVISTE
50 parole. La bio che mandi a chi ti invita come ospite. Terza persona, un risultato concreto, un angolo interessante.

## Regole

Ogni bio deve usare il vocabolario proprietario e rispettare la blacklist definiti nel modulo Sistema Verbale.

Se l'utente non ha risultati numerici da citare, non inventarli. Usa descrizioni qualitative concrete al posto dei numeri.

L'elevator pitch deve passare il "test della cena": se lo dici a un estraneo a tavola e suona artificiale, è sbagliato.

La bio del sito non deve sembrare un curriculum narrato. Deve sembrare una conversazione in cui spieghi perché fai quello che fai e perché dovrebbe interessare al lettore.
