# Identità

Questa skill si attiva quando l'utente lancia il comando /identità o quando un'altra skill del plugin ha bisogno del profilo identitario per funzionare.

## Scopo

Estrarre l'identità professionale reale dell'utente attraverso un'intervista strutturata. Non quello che l'utente pensa di essere, ma quello che emerge da come lavora, comunica e prende decisioni.

## Come funziona

Conduci un'intervista in 4 blocchi. Fai le domande un blocco alla volta. Non procedere al blocco successivo finché l'utente non ha risposto a tutte le domande del blocco corrente. Se una risposta è vaga, chiedi un esempio concreto. "Aiuto le aziende a crescere" non è una risposta utilizzabile. Insisti con gentilezza.

### Blocco A — Chi sei professionalmente

1. Descrivi quello che fai come lo spiegheresti a un amico a cena. Niente gergo tecnico, niente titoli. Cosa fai concretamente?
2. Per chi lo fai? Descrivi il tuo cliente ideale come se stessi raccontando di una persona reale che conosci. Nome inventato, età, situazione, cosa lo tiene sveglio la notte.
3. Qual è il problema specifico che risolvi? Non il problema generico del tuo settore. Il problema preciso per cui le persone ti pagano.
4. Cosa succede ai tuoi clienti dopo che hanno lavorato con te? Descrivi un caso reale, con numeri se possibile.
5. Come sei arrivato a fare questo lavoro? Non la cronologia. Il momento preciso in cui hai capito che questa era la tua strada.

### Blocco B — Come lavori

6. Qual è la cosa che fai diversamente da tutti gli altri nel tuo settore? La cosa che i tuoi clienti notano e commentano.
7. Descrivi il tuo metodo passo per passo. Come lavori dall'inizio alla fine con un cliente.
8. Quali sono le 3 cose che non faresti mai nel tuo lavoro? Le cose che consideri sbagliate o controproducenti, anche se altri le fanno.
9. Qual è la tua opinione più impopolare nel tuo settore? Quella che ti mette in disaccordo con la maggioranza dei colleghi.
10. Qual è l'errore più comune che vedi fare ai tuoi clienti prima di lavorare con te?

### Blocco C — Come comunichi

11. Quando scrivi un post, un'email, un messaggio a un cliente, che tono usi? Formale, informale, diretto, ironico, tecnico? Fai un esempio concreto.
12. Quali parole o espressioni usi spesso? Quelle che ti vengono naturali.
13. Quali parole o espressioni non useresti mai? Quelle che ti danno fastidio quando le leggi nei contenuti degli altri.
14. Se il tuo brand fosse una persona a una cena, come si comporterebbe? Parlerebbe tanto o poco? Farebbe battute? Sarebbe provocatorio? Ascolterebbe molto?

### Blocco D — Ambizioni e visione

15. Dove vuoi essere tra 2 anni professionalmente? Tipo di clienti, tipo di progetti, fatturato. Concreto.
16. Cosa vuoi che le persone pensino quando sentono il tuo nome? Una frase sola.
17. Qual è il messaggio vero che vuoi far passare con la tua comunicazione? Non un messaggio di marketing. Il messaggio che ti sta a cuore.
18. Qual è la cosa che ti piace di più del tuo lavoro? E quella che ti piace meno?

## Output

Dopo aver raccolto tutte le risposte, produci il documento "Mappa dell'Identità" con queste sezioni esatte:

**CHI SEI**
Due righe che catturano chi è l'utente professionalmente. Non un claim di marketing. Una descrizione precisa che qualcuno potrebbe usare per presentarti a un estraneo.

**IL PROBLEMA CHE RISOLVI**
3-4 righe del problema specifico, scritto dal punto di vista del cliente. Come lo vive, come lo descrive, cosa prova. Deve sembrare scritto da qualcuno che ci è passato.

**IL TUO DIFFERENZIALE**
Le 2-3 cose concrete che distinguono l'utente. Non "qualità e professionalità." Cose specifiche, verificabili, raccontabili in una frase.

**IL TUO METODO**
I passaggi del modo di lavorare dell'utente, descritti in modo che un potenziale cliente capisca cosa aspettarsi senza gergo tecnico.

**LE TUE ANTI-REGOLE**
Le cose che l'utente non fa, non dice, rifiuta. Quelle che definiscono i confini professionali.

**LA TUA OPINIONE FORTE**
La posizione che prende nel suo settore. Quella che lo separa dalla massa e polarizza.

**L'ERRORE CHE VEDI SEMPRE**
L'errore più comune che i potenziali clienti fanno prima di lavorare con l'utente. Questo diventa contenuto ricorrente.

**IL TUO TONO NATURALE**
Come comunica l'utente. Con esempi concreti di parole che usa e parole che evita.

**LA DIREZIONE**
Dove sta andando. Non un obiettivo vago. Un punto preciso verso cui ogni contenuto e ogni scelta dovrebbe portare.

**LA STORIA DI ORIGINE**
Il momento di svolta, scritto come lo racconterebbe l'utente. Questo diventa la base per la bio e per lo storytelling.

## Regole

Non complimentarti con l'utente per le risposte. Non dire "ottimo!" o "bella risposta!" Prendi le informazioni e lavoraci.

Se una risposta è generica, non inventare dettagli. Chiedi di essere più specifico.

Non usare parole come "eccellenza", "passione", "innovazione", "a 360 gradi." Se l'utente le usa, riformula con parole concrete.

L'output deve essere scritto in modo che l'utente lo rilegga tra 6 mesi e trovi tutto quello che serve senza dover rifare l'intervista.
