# Strategia

Questa skill si attiva quando l'utente lancia il comando /strategia. Richiede che i moduli Identità e Posizionamento siano stati completati.

## Scopo

Costruire la strategia di differenziazione e i pilastri di contenuto. Tutto quello che serve per sapere cosa comunicare, come e quando.

## Output

### I TUOI 3 PILASTRI DI CONTENUTO

I 3 temi su cui costruire tutta la comunicazione. Per ogni pilastro:
- Il tema (specifico, non generico)
- Perché è coerente con il posizionamento
- 10 titoli di contenuto pronti da usare (specifici per l'utente, non riciclabili)
- Il formato migliore per ogni titolo (post, carosello, reel, newsletter, articolo)
- La frequenza consigliata per questo pilastro

### IL TUO FORMAT PROPRIETARIO

Un format ricorrente che diventa riconoscibile nel tempo. Deve essere:
- Replicabile ogni settimana senza sforzo creativo eccessivo
- Impossibile da copiare perché legato all'esperienza specifica dell'utente
- Capace di generare engagement, salvataggi e condivisioni

Descrivi il format nel dettaglio: nome, struttura, frequenza, 3 esempi completi scritti per intero.

### IL TUO ANTI-POSIZIONAMENTO

Cosa NON sei. Cosa NON fai. Contro chi ti posizioni. Le cose che critichi apertamente nel tuo settore. 3-5 posizioni nette con la spiegazione di perché prenderle pubblicamente rafforza il brand.

### PIANO 90 GIORNI

Diviso in 3 fasi. Per ogni fase:

**Fase 1 (giorni 1-30) — Fondazione**
- Obiettivo specifico della fase
- Frequenza di pubblicazione
- Mix di contenuti (quanti per ogni pilastro, quanti format proprietari)
- 12 contenuti con: titolo, formato, angolo, pilastro di riferimento, 2 righe di brief su cosa dire

**Fase 2 (giorni 31-60) — Autorevolezza**
- Evoluzione della frequenza
- Introduzione di contenuti più polarizzanti
- 12 contenuti con brief

**Fase 3 (giorni 61-90) — Conversione**
- Contenuti orientati alla vendita
- Come integrare le call to action senza sembrare disperati
- 12 contenuti con brief
- Come misurare i risultati (metriche specifiche per canale)

### DISTRIBUZIONE

Per ogni contenuto del piano, indica:
- Il canale primario (dove pubblicarlo per primo)
- I canali secondari (dove ripubblicarlo adattato)
- Come adattarlo per ogni canale (cosa cambia tra la versione LinkedIn e quella Instagram)

## Regole

I 36 contenuti del piano devono essere tutti diversi. Niente "variazione sul tema" ripetuta 4 volte.

I titoli devono essere specifici per l'utente. "5 errori che stai facendo" è generico. "5 errori che vedo in ogni preventivo da architetto che leggo" è specifico.

Il format proprietario non è "ogni lunedì posto una citazione." È qualcosa di strutturato che solo l'utente può fare perché si basa sulla sua esperienza.
