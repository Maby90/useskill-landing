# Funnel

Questa skill si attiva quando l'utente lancia il comando /funnel. Richiede che i moduli Identità, Posizionamento e Offerta siano stati completati.

## Scopo

Progettare il percorso completo che un potenziale cliente fa dalla scoperta all'acquisto. Non un funnel teorico. Un sistema concreto con ogni pezzo descritto nel dettaglio.

## Output

### MAPPA DEL FUNNEL

Disegna il percorso in fasi. Per ogni fase:

**FASE 1 — SCOPERTA**
Come il potenziale cliente ti trova per la prima volta. Canali specifici (non "i social media" ma "LinkedIn tramite post educativi sul pilastro X"). Per ogni canale:
- Tipo di contenuto che attira l'attenzione
- Volume necessario (quanti contenuti a settimana)
- Metriche da monitorare
- Errori da evitare

**FASE 2 — PRIMO VALORE**
Cosa riceve il potenziale cliente come primo assaggio gratuito. Progetta il lead magnet o il contenuto di ingresso:
- Formato (PDF, video, mini-consulenza, template, checklist, quiz)
- Contenuto specifico (non "una guida su X" ma il titolo, la struttura, i capitoli)
- Come si scarica / accede (landing page, DM, link in bio)
- Email o messaggio di consegna

**FASE 3 — NURTURING**
Come mantieni il contatto con chi ha ricevuto il primo valore ma non ha ancora comprato:
- Sequenza email (numero, frequenza, tono, obiettivo di ogni email)
- Contenuti social che parlano a questa fascia
- Tempo medio che passa tra primo contatto e acquisto nel settore dell'utente

**FASE 4 — QUALIFICAZIONE**
Come capisci chi è pronto a comprare e chi no:
- Segnali di interesse (risposte alle email, click, interazioni social, richieste dirette)
- Domande di qualificazione (cosa chiedere prima di investire tempo in una call)
- Come gestire chi non è qualificato (senza bruciare il rapporto)

**FASE 5 — CONVERSIONE**
Il momento della vendita:
- Come avviene (call, proposta scritta, pagina di vendita, incontro)
- Script o struttura della conversazione di vendita
- Come presentare il prezzo
- Come gestire le obiezioni più comuni (elenca le 5 obiezioni principali con la risposta)
- Follow-up se il potenziale cliente non decide subito

**FASE 6 — ATTIVAZIONE**
Cosa succede subito dopo l'acquisto:
- Onboarding del cliente (primi passi, aspettative, tempistiche)
- Come ridurre il buyer's remorse nelle prime 48 ore
- Prima comunicazione post-acquisto

**FASE 7 — REFERRAL**
Come trasformare i clienti soddisfatti in ambasciatori:
- Quando chiedere il referral (momento preciso nel percorso)
- Come chiederlo senza sembrare disperati
- Cosa offrire in cambio
- Come raccogliere testimonianze utili (le domande giuste da fare)

### STRUMENTI NECESSARI

Per ogni fase, elenca gli strumenti concreti che servono:
- Pagine web (landing page, pagina servizi, thank you page)
- Email (sequenze, template, automazioni)
- Contenuti (lead magnet, post, newsletter)
- Documenti (preventivi, contratti, questionari)
- Software (CRM, email marketing, calendario prenotazioni)

Per ogni strumento, indica se l'utente ce l'ha già, se deve crearlo, o se può farne a meno.

### METRICHE

Le metriche che contano per ogni fase:
- Cosa misurare
- Con che frequenza
- Quale numero è buono, quale è un segnale di allarme
- Cosa fare se una metrica è sotto la soglia

## Regole

Il funnel deve essere realistico per una persona sola o un team piccolo. Non progettare un sistema che richiede 3 persone full-time per funzionare.

Ogni pezzo del funnel deve esistere per un motivo. Se togli un pezzo e il funnel funziona lo stesso, quel pezzo non serve.

Non suggerire mai strumenti a pagamento se esiste un'alternativa gratuita che funziona per il volume dell'utente.

Le obiezioni nella fase di conversione devono essere specifiche per il settore, non generiche ("è troppo caro" è generica, "non sono sicuro che funzioni per il mio tipo di clientela" è specifica).
