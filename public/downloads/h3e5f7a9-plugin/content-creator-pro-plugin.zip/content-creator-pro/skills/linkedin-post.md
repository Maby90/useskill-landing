# LinkedIn Post

Questa skill si attiva quando l'utente chiede di scrivere un post LinkedIn, o quando usa il comando /post.

## Input

L'utente fornisce un'idea, anche grezza. Può essere una frase, un concetto, un'esperienza, una riflessione. Non deve essere strutturata.

## Output

Un post LinkedIn completo, pronto da copiare e pubblicare. Il post deve avere questa struttura:

### Hook (prima riga)

La riga che appare prima di "Vedi altro". Deve fermare lo scroll. Deve creare una tensione, una curiosità, o un riconoscimento immediato ("questo parla di me"). Non deve essere clickbait. Non deve fare promesse esagerate. Deve essere onesta e specifica.

Tecniche che funzionano per l'hook: una dichiarazione controintuitiva, una domanda che il lettore si è già posto, un numero preciso che sorprende, l'inizio di una storia senza contesto.

Tecniche da evitare: "Ho imparato una lezione importante", "Ecco cosa ho capito", domande generiche come "Ti è mai capitato?", affermazioni ovvie che non aggiungono niente.

### Corpo

Il contenuto vero del post. Sviluppa l'idea dell'hook con profondità. Usa frasi brevi. Vai a capo spesso (LinkedIn premia la leggibilità verticale). Ogni paragrafo deve aggiungere qualcosa di nuovo: un dettaglio, un esempio, un passaggio logico.

Non riempire con frasi di transizione inutili. Se una frase non aggiunge informazione o emozione, toglila.

Se il post racconta un'esperienza, sii specifico: nomi di situazioni reali, numeri concreti, dettagli che solo chi c'era potrebbe conoscere. La specificità è ciò che rende un post credibile.

### Chiusura

Una frase o due che chiudono il cerchio aperto dall'hook. La chiusura può essere un invito alla discussione (una domanda vera, non retorica), una presa di posizione netta, o un ribaltamento dell'aspettativa iniziale.

Non usare mai "E tu cosa ne pensi?" come chiusura. Non usare "Condividi se sei d'accordo". Non usare call to action che suonano come template.

## Formato

Il post non deve superare le 1300 battute (circa 200 parole). Se il concetto richiede più spazio, suggerisci di farne un carosello con il comando /carosello.

Non usare emoji se il profilo della voce non le prevede. Non usare hashtag nel corpo del testo. Se servono, mettili in fondo, separati dal contenuto, massimo 3.

## Regole

Rispetta il profilo del tono di voce dell'utente. Se è disponibile nella conversazione o nel progetto, usalo come guida per ogni scelta lessicale e strutturale. Se non è disponibile, scrivi in modo diretto, concreto, senza fronzoli.

Non usare mai frasi fatte da LinkedIn: "sono entusiasta di annunciare", "un viaggio incredibile", "grato per questa opportunità", "lezione di vita". Se una frase la leggeresti in 50 post diversi, non è abbastanza specifica.

Non usare trittici di aggettivi. Non usare espressioni come "in questo contesto", "è fondamentale sottolineare", "un approccio olistico".

L'output deve sembrare scritto da una persona vera con un'opinione precisa, non da un'AI che cerca di sembrare umana.
