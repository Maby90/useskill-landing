# Brand Voice

Questa skill si attiva quando l'utente chiede di analizzare il proprio stile di scrittura, creare un profilo della propria voce, o quando un'altra skill del plugin ha bisogno del contesto del tono di voce.

## Come funziona

L'utente fornisce almeno 3 testi che ha scritto personalmente. Possono essere post, email, articoli, messaggi a clienti, qualsiasi cosa scritta con la propria voce reale.

Analizza ogni testo e produci una Guida del Tono di Voce strutturata in queste sezioni:

### 1. Profilo stilistico

Descrivi come scrive questa persona. Lunghezza media delle frasi. Uso della punteggiatura. Preferenza per frasi brevi e dirette o per periodi più articolati. Tendenza a usare domande retoriche, esclamazioni, parentesi. Livello di formalità. Densità del testo.

### 2. Vocabolario ricorrente

Elenca le parole e le espressioni che questa persona usa spesso. Segnala anche quelle che evita. Distingui tra lessico tecnico del settore e lessico personale. Identifica eventuali intercalari o modi di dire caratteristici.

### 3. Personalità comunicativa

Descrivi il carattere che emerge dalla scrittura. Questa persona è diretta o preferisce arrivare al punto per gradi? Usa l'ironia? È assertiva o più riflessiva? Tende a dare ordini, suggerimenti, o a ragionare insieme al lettore?

### 4. Struttura preferita

Analizza come organizza i contenuti. Parte dal problema o dalla soluzione? Usa esempi concreti o resta sul teorico? Apre con una domanda, con un'affermazione forte, con un aneddoto? Come chiude: con una call to action, con una riflessione, con una domanda aperta?

### 5. Prompt system

Genera un blocco di istruzioni pronto da incollare nel system prompt di qualsiasi AI. Il blocco deve contenere tutte le informazioni raccolte nei punti precedenti, scritte come direttive operative. Formato: testo in seconda persona ("Scrivi come...", "Evita...", "Preferisci...").

## Regole

Non inventare caratteristiche che non emergono dai testi. Se un tratto non è evidente, non inserirlo. Meglio un profilo preciso e incompleto che uno ricco e inventato.

Non usare trittici di aggettivi. Non usare espressioni come "un tono caldo e coinvolgente" o "comunicazione empatica e professionale". Descrivi con esempi concreti tratti dai testi analizzati.

Il profilo deve essere immediatamente utilizzabile. Chi lo legge deve capire in 30 secondi come scrive questa persona, senza interpretazioni ambigue.
