# Carosello Instagram

Questa skill si attiva quando l'utente chiede di creare un carosello Instagram, o quando usa il comando /carosello.

## Input

L'utente fornisce un concetto, un tema, o un'idea da sviluppare in formato carosello. Può essere vago o preciso.

## Output

Un carosello di 10 slide con il testo completo per ogni slide. Ogni slide deve rispettare queste regole:

### Slide 1 (Cover)

L'unica slide che il lettore vede nello scroll. Deve fermare il pollice. Il testo deve essere brevissimo (massimo 8-10 parole) e creare una tensione che spinge a scorrere. Non deve rivelare il contenuto, deve far venire voglia di scoprirlo.

Non usare domande generiche come "Vuoi sapere come?". Non usare "5 cose che devi sapere su...". Usa affermazioni nette, controintuitive, o che toccano un nervo scoperto del lettore.

### Slide 2-9 (Contenuto)

Ogni slide sviluppa un punto del tema. Le regole per il testo:

Massimo 30-40 parole per slide. Su mobile il testo deve essere leggibile senza sforzo. Se una slide ha più di 40 parole, il lettore la salta.

Ogni slide deve funzionare anche da sola, come se fosse un post indipendente. Chi vede solo quella slide deve capire il concetto senza aver letto le precedenti.

Alterna slide di concetto (una frase forte, un dato, un'affermazione) a slide di sviluppo (la spiegazione, l'esempio, il dettaglio). Questo ritmo tiene alta l'attenzione.

Non numerare le slide ("Punto 1, Punto 2..."). Il carosello non è una lista, è un racconto visivo. Il flusso deve essere narrativo, non scolastico.

### Slide 10 (Chiusura + CTA)

L'ultima slide chiude il cerchio aperto dalla cover e include un invito all'azione. La call to action deve essere una sola: salva il post, commenta, visita il link in bio, condividi con qualcuno. Non tutte insieme.

La chiusura migliore è quella che fa sentire il lettore più competente di prima. Se dopo 10 slide sa fare qualcosa che prima non sapeva fare, il carosello ha funzionato.

## Formato dell'output

Presenta ogni slide come un blocco separato con il numero della slide e il testo. Aggiungi una nota sul tipo di visual consigliato per ogni slide (testo su sfondo pieno, screenshot, grafico, citazione evidenziata) per facilitare il lavoro grafico.

## Regole

Rispetta il profilo del tono di voce se disponibile.

Non usare emoji nel testo delle slide. Non usare hashtag nel corpo del carosello (quelli vanno nella caption, non nelle slide).

Non scrivere in "tono da coach": "ricorda che il tuo valore non dipende dai like", "ogni giorno è un'opportunità". Scrivi cose concrete e utili.

Il carosello deve insegnare qualcosa o cambiare una prospettiva. Se dopo averlo letto il lettore pensa "questo lo sapevo già", il carosello non funziona.
