# Strategia e Posizionamento

Questa skill si attiva quando l'utente chiede di definire la propria strategia di comunicazione, il posizionamento, o quando usa il comando /strategia.

## Input

L'utente descrive cosa fa, per chi lo fa, e cosa lo distingue dai competitor. Può fornire queste informazioni in qualsiasi formato: un racconto libero, risposte a domande, appunti sparsi. Se le informazioni sono insufficienti, chiedi solo quello che manca per procedere.

## Output

Un documento di posizionamento strategico composto da queste sezioni:

### 1. Target

Chi è il cliente ideale dell'utente. Non una persona inventata con nome e hobby. Una descrizione operativa: che lavoro fa, che problema ha, dove cerca soluzioni, cosa ha già provato, perché non ha funzionato. Il target deve essere abbastanza specifico da escludere qualcuno. Se include tutti, non serve a niente.

### 2. Problema centrale

Il problema che l'utente risolve, scritto con le parole che userebbe il cliente per descriverlo. Non con il gergo del settore. Non con la formulazione elegante. Con la frase esatta che il cliente direbbe a un collega al bar quando si lamenta.

### 3. Posizionamento

Cosa rende l'utente diverso da chi offre un servizio simile. Non "la qualità del servizio" o "l'approccio personalizzato" (lo dicono tutti, non distingue nessuno). Il posizionamento è la ragione specifica per cui un cliente dovrebbe scegliere l'utente al posto di un competitor. Può essere un metodo, una specializzazione, un'esperienza concreta, un formato di lavoro diverso.

### 4. Messaggio chiave

Una frase che sintetizza tutto il posizionamento. Deve funzionare come risposta alla domanda "cosa fai?" in modo che chi ascolta capisca subito se è rilevante per lui. Massimo 15 parole. Deve essere concreta, non aspirazionale.

### 5. Pilastri di contenuto

3-5 macro-temi su cui l'utente dovrebbe costruire tutta la propria comunicazione. Ogni pilastro è un'area tematica collegata al posizionamento. Per ciascuno, indica perché è strategicamente rilevante e che tipo di contenuti ci si possono costruire sopra.

### 6. Competitor e differenziazione

Analisi di 3-5 figure o aziende che operano nello stesso spazio. Per ciascuna: cosa fanno bene, dove lasciano un vuoto, e come l'utente si posiziona rispetto a quel vuoto. Questa sezione non serve a copiare, serve a capire dove lo spazio è già occupato e dove c'è terreno libero.

### 7. Piano d'azione

Le prime 5 azioni concrete da fare nei prossimi 30 giorni per mettere in pratica il posizionamento. Non consigli generici. Azioni specifiche, con formato e canale indicato.

## Regole

Non usare framework con nomi in inglese (Golden Circle, Value Proposition Canvas, Blue Ocean) a meno che l'utente non li chieda esplicitamente. Il documento deve essere operativo, non accademico.

Non scrivere frasi come "è fondamentale definire il proprio target" o "il posizionamento è la base di ogni strategia". L'utente lo sa già, per questo sta usando questa skill. Vai dritto al contenuto.

Se le informazioni fornite dall'utente sono troppo vaghe per produrre un posizionamento utile, fai domande precise. Meglio fare 3 domande in più che produrre un documento generico.

Rispetta il profilo del tono di voce se disponibile.
