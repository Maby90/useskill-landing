# Newsletter

Questa skill si attiva quando l'utente chiede di scrivere una newsletter, o quando usa il comando /newsletter.

## Input

L'utente fornisce i punti chiave del contenuto. Possono essere appunti sparsi, bullet point, concetti in disordine, link, o anche solo il tema della settimana. La skill lavora con qualsiasi livello di struttura in ingresso.

## Output

Una newsletter completa composta da queste parti:

### Oggetto

La riga che decide se la newsletter viene aperta o ignorata. Deve essere breve (massimo 50 caratteri), specifica, e creare abbastanza curiosità da giustificare il clic. Non deve sembrare spam. Non deve usare maiuscole aggressive o punteggiatura eccessiva.

L'oggetto migliore è quello che sembra scritto da una persona che ti manda un'email, non da un software di email marketing.

### Apertura

Le prime 2-3 righe dopo l'oggetto. Questo è il momento in cui il lettore decide se continuare o chiudere. L'apertura deve agganciare subito con qualcosa di concreto: un fatto, un'osservazione, una domanda diretta, un aneddoto brevissimo.

Non aprire con "Ciao, spero che tu stia bene". Non aprire con "In questa newsletter parleremo di". Entra nel contenuto dal primo rigo.

### Corpo

Il contenuto principale. Organizzato in blocchi separati da spazi bianchi, ognuno con un'idea chiara. Ogni blocco deve essere autosufficiente: anche se il lettore ne legge solo uno, deve trarne valore.

Usa frasi corte. Vai a capo quando cambi concetto. Se citi dati o fonti, sii preciso. Se racconti un'esperienza, sii specifico.

La lunghezza totale del corpo dipende dal contenuto: non allungare per riempire e non tagliare se il valore c'è. Come riferimento, una newsletter che si legge in 3-4 minuti funziona bene per la maggior parte dei professionisti.

### Chiusura

Un invito all'azione singolo e chiaro. Una sola cosa che il lettore deve fare dopo aver letto. Può essere rispondere all'email, cliccare un link, provare qualcosa, riflettere su una domanda.

Non mettere tre call to action diverse. Non chiudere con "Se ti è piaciuta, condividila con un collega". Chiudi con qualcosa che ha valore per chi legge, non per chi scrive.

## Regole

Rispetta il profilo del tono di voce se disponibile. La newsletter è il formato più personale: il tono deve essere quello di una conversazione tra il mittente e il lettore, non quello di un comunicato.

Non usare strutture a elenchi puntati nel corpo della newsletter. Scrivi in prosa, in paragrafi. Se devi elencare cose, fallo dentro una frase naturale.

Non usare espressioni da template: "questa settimana voglio condividere con te", "ecco 3 cose che ho imparato", "pronto? Partiamo". Scrivi come scriveresti a una persona che stimi, non a un database di contatti.
