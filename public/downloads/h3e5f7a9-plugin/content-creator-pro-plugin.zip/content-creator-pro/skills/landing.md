# Landing Page Copy

Questa skill si attiva quando l'utente chiede di scrivere i testi per una pagina di vendita, una pagina servizi, una bio professionale, o quando usa il comando /landing.

## Input

L'utente descrive cosa vende, a chi, e qual è l'obiettivo della pagina (raccogliere contatti, vendere un servizio, presentare un'offerta). Può fornire dettagli su prezzo, benefici, testimonianze, obiezioni frequenti.

## Output

I testi completi della pagina, sezione per sezione. Ogni sezione ha un ruolo preciso nel portare il visitatore dalla curiosità all'azione.

### Hero (la prima cosa che si vede)

Headline: una frase che dice cosa ottiene il visitatore. Non cosa fa l'utente. Non "Consulenza di marketing strategico". Piuttosto "Smetti di pubblicare contenuti che nessuno legge". La headline risponde alla domanda "perché dovrei restare su questa pagina?" in meno di 3 secondi.

Sottotitolo: una o due righe che specificano come. Il meccanismo, il formato, il risultato concreto. Se la headline promette un risultato, il sottotitolo spiega la strada.

CTA primaria: il bottone. Testo breve, specifico, orientato all'azione. "Prenota una call gratuita" funziona. "Scopri di più" no, perché non dice cosa succede dopo il clic.

### Problema

Una sezione che descrive il problema del visitatore con le sue parole. Chi legge deve pensare "parla di me". Non usare il problema come pretesto per vantarsi della soluzione. Resta sul dolore del lettore. Sii specifico: non "molte aziende faticano a", ma la situazione concreta che il target vive ogni giorno.

### Soluzione

Cosa offre l'utente e come risolve il problema descritto sopra. Il collegamento tra problema e soluzione deve essere diretto: "il problema è X, la soluzione è Y, e funziona così". Niente passaggi intermedi vaghi.

### Benefici

Quello che cambia concretamente nella vita o nel lavoro del cliente. Non le caratteristiche del servizio. Non "analisi approfondita del mercato" ma "sai esattamente dove investire il tuo budget il mese prossimo". Ogni beneficio deve completare la frase "dopo aver lavorato con me, tu...".

### Prova sociale

Se l'utente ha testimonianze, risultati, numeri, o casi studio, questa sezione li presenta. Se non li ha, suggerisci alternative: il numero di clienti serviti, i settori coperti, le esperienze precedenti, le certificazioni. Non inventare prove sociali. Se non ci sono, salta la sezione e segnalalo all'utente.

### Obiezioni

Le domande e i dubbi che il visitatore ha in testa prima di agire. Per ogni obiezione, una risposta breve e onesta. Non difensiva, non aggressiva. Trasparente. Se il prezzo è alto, spiega perché e cosa include. Se il processo è lungo, spiega cosa succede in ogni fase.

### CTA finale

Ripeti l'invito all'azione con una formulazione diversa dalla hero. A questo punto il visitatore ha letto tutto, ha capito il valore, ha visto le prove. Il CTA finale deve sembrare il passo naturale successivo.

## Regole

Non scrivere in terza persona ("l'azienda offre..."). Scrivi in prima persona (io) o in seconda (tu). La pagina è una conversazione tra chi vende e chi potrebbe comprare.

Non usare superlativi senza prove ("il miglior servizio", "risultati straordinari", "un'esperienza unica"). Se qualcosa è il migliore, dimostralo con un dato. Altrimenti non dirlo.

Non scrivere muri di testo. Ogni sezione deve essere leggibile in pochi secondi. Frasi corte, paragrafi brevi, spazi bianchi tra le sezioni.

Rispetta il profilo del tono di voce se disponibile.

Se l'utente non fornisce abbastanza informazioni per scrivere una sezione (es. non ha testimonianze), segnala cosa manca e suggerisci come raccoglierlo. Non riempire con testo generico.
