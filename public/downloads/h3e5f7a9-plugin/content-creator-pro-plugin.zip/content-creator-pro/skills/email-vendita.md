# Email di Vendita e Sequenze

Questa skill si attiva quando l'utente chiede di scrivere email commerciali, sequenze di follow-up, email di vendita, o quando usa il comando /email.

## Input

L'utente descrive il contesto: a chi scrive, cosa vuole ottenere, e qual è la relazione attuale con il destinatario (contatto freddo, lead che ha scaricato qualcosa, cliente che ha fatto una call, ex cliente da riattivare).

## Tipi di sequenze

### Cold outreach (contatto freddo)

Sequenza di 3 email per presentarsi a qualcuno che non ti conosce.

Email 1: aggancia con qualcosa di specifico sul destinatario (un post che ha scritto, un progetto che ha lanciato, un problema del suo settore). Presenta il tuo lavoro in una riga. Chiudi con una domanda leggera, non con "possiamo sentirci?". Piuttosto "ha senso per te?" o "è un tema su cui stai lavorando?".

Email 2 (3-4 giorni dopo): non ripetere la prima email. Aggiungi un elemento nuovo: un caso studio, un risultato concreto, un'osservazione specifica sul lavoro del destinatario. Brevissima. 4-5 righe massimo.

Email 3 (5-7 giorni dopo): l'ultimo tentativo. Sii diretto: "Ti ho scritto due volte su [tema]. Se non è il momento giusto, nessun problema. Se invece ti interessa, rispondere a questa email basta." Fine.

### Follow-up post call

Sequenza di 2 email dopo una call conoscitiva.

Email 1 (entro 24 ore): ringrazia senza essere servile. Riassumi in 3-4 righe cosa è emerso dalla call e quali sono i prossimi passi. Se devi mandare una proposta, indica quando la riceverà.

Email 2 (3-5 giorni dopo, se non ha risposto): breve, diretta. "Ti ho mandato [cosa] il [giorno]. Volevo assicurarmi che ti fosse arrivato e capire se hai domande." Niente pressione.

### Riattivazione contatto

Sequenza di 2 email per contatti che si sono raffreddati.

Email 1: non fare finta che il silenzio non ci sia stato. Riconosci il tempo passato. Offri qualcosa di nuovo: un caso studio recente, un cambiamento nel tuo servizio, un'osservazione sul settore del destinatario che potrebbe interessargli.

Email 2 (7 giorni dopo): ancora più breve. "Se il timing non è giusto, capisco perfettamente. Se invece la situazione è cambiata, rispondi a questa email e riprendiamo il discorso."

### Vendita dopo lead magnet

Sequenza di 3 email per chi ha scaricato un contenuto gratuito.

Email 1 (immediata): consegna il contenuto. Spiega brevemente come usarlo. Non vendere niente in questa email.

Email 2 (2-3 giorni dopo): mostra il risultato che si ottiene con il tuo servizio a pagamento. Un esempio concreto, non una promessa. "Un cliente nel tuo settore ha ottenuto [risultato specifico] in [tempo]." Chiudi con un link o un invito a saperne di più.

Email 3 (5-7 giorni dopo): l'offerta vera. Spiega cosa include, quanto costa, e cosa succede dopo l'acquisto. Un unico CTA chiaro.

## Regole per tutte le email

L'oggetto deve essere breve (massimo 40 caratteri) e non sembrare marketing. Gli oggetti migliori sembrano scritti da una persona vera: "una domanda su [progetto]", "dopo la nostra call", "[nome], una cosa".

Il tono è quello di una persona che scrive a un'altra persona. Non quello di un'azienda che scrive a un prospect. Niente formule come "mi permetto di scriverle", "vorrei presentarle", "in qualità di". Scrivi come scriveresti a un conoscente professionale.

La firma non deve avere 15 righe con logo, numero di telefono, indirizzo, link ai social, e citazione motivazionale. Nome, ruolo, un link. Basta.

Ogni email deve avere una sola call to action. Non "visita il sito, seguici su LinkedIn, e rispondi a questa email". Una cosa sola.

Rispetta il profilo del tono di voce se disponibile.

Non scrivere email lunghe. Se puoi dirlo in 5 righe, non usarne 15. Le email commerciali migliori sono quelle che si leggono in 30 secondi.
