# Calendario Editoriale

Questa skill si attiva quando l'utente chiede di creare un piano editoriale o un calendario di contenuti, o quando usa il comando /calendario.

## Input

L'utente fornisce il proprio settore, gli obiettivi di comunicazione e il periodo da coprire. Può aggiungere vincoli come la frequenza di pubblicazione, i canali da usare, i formati preferiti, o i temi da evitare.

Se l'utente non specifica il periodo, genera un calendario di 30 giorni.

## Output

Un calendario editoriale con un'idea di contenuto per ogni giorno di pubblicazione. Ogni idea include:

**Giorno e data.** Il giorno della settimana e la data.

**Formato.** Il tipo di contenuto: post LinkedIn, carosello Instagram, newsletter, storia, reel, articolo blog. Alterna i formati per evitare la monotonia.

**Angolo.** L'approccio specifico del contenuto. Non basta scrivere "post su LinkedIn sul branding". Serve l'angolo preciso: "racconta la volta in cui hai perso un cliente perché il tuo profilo LinkedIn era vuoto". L'angolo è ciò che rende un'idea pubblicabile.

**Hook.** La prima riga del contenuto, già scritta. Questo aiuta l'utente a capire immediatamente il tono e a partire con la produzione.

**Note.** Se l'idea si presta a un formato specifico (es. il carosello con il comando /carosello, o il post con /post), segnalalo.

## Regole per la generazione delle idee

Ogni idea deve superare il test "la pubblicherei davvero?". Se la risposta è no, scartala e pensane un'altra. Le idee generiche che suonano bene ma non dicono niente sono il motivo per cui la maggior parte dei calendari editoriali finisce in un cassetto.

Alterna tra queste categorie di contenuto:

Storie personali ed esperienze professionali. Contenuti educativi che insegnano qualcosa di specifico. Opinioni di settore che prendono una posizione netta. Case study o esempi concreti dal lavoro. Contenuti interattivi che invitano alla conversazione (sondaggi, domande, scelte).

Non mettere mai due contenuti della stessa categoria di fila. Il ritmo è parte della strategia.

Non suggerire mai idee come "condividi una citazione ispirazionale", "fai un post motivazionale", "parla del tuo perché". Questi riempitivi sono il segnale che il calendario è stato fatto per riempire spazi, non per produrre risultati.

## Formato dell'output

Presenta il calendario come una tabella o un elenco strutturato per settimana. Ogni settimana ha una nota tematica che collega le idee tra loro. Il calendario deve avere un filo conduttore, non essere una lista di idee scollegate.

## Regole

Rispetta il profilo del tono di voce se disponibile. Le idee e gli hook devono essere coerenti con il modo in cui l'utente comunica.

Se l'utente specifica di pubblicare solo su certi canali, limita i formati a quelli compatibili. Se pubblica solo su LinkedIn, non suggerire caroselli Instagram.

Non usare espressioni come "contenuto di valore", "engagement", "community". Parla della comunicazione come ne parlerebbe un professionista al bar con un collega, non come un manuale di marketing.
