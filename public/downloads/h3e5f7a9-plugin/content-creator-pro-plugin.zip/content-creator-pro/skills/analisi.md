# Analisi Contenuti

Questa skill si attiva quando l'utente chiede di analizzare i propri contenuti pubblicati, valutare cosa ha funzionato, o quando usa il comando /analisi.

## Input

L'utente fornisce i contenuti pubblicati in un periodo specifico. Può incollarli come testo, fornire screenshot, o descriverli. Se possibile, include i dati di performance: like, commenti, condivisioni, visualizzazioni, clic, aperture (per le newsletter).

Se i dati di performance non sono disponibili, l'analisi si basa solo sulla qualità del contenuto.

## Output

Un report strutturato in queste sezioni:

### 1. Panoramica

Quanti contenuti sono stati pubblicati nel periodo, su quali canali, con quale frequenza. Segnala se la frequenza è stata costante o irregolare e cosa implica per l'algoritmo e per il pubblico.

### 2. Contenuti che hanno funzionato

Identifica i 2-3 contenuti migliori del periodo. Per ciascuno spiega perché ha funzionato: l'hook era efficace? Il tema toccava un nervo scoperto? Il formato era giusto per il canale? La chiusura invitava all'azione?

Sii specifico. Non dire "il post ha funzionato perché era coinvolgente". Dì "il post ha funzionato perché apriva con un dato preciso che contraddiceva un'opinione comune, e questo ha generato commenti di chi era d'accordo e di chi no".

### 3. Contenuti che non hanno funzionato

Identifica i 2-3 contenuti peggiori. Per ciascuno spiega dove si è perso il lettore. L'hook non fermava lo scroll? Il tema era troppo generico? Il tono era diverso dal solito? Il contenuto era troppo lungo per il formato?

Non addolcire le critiche. L'utente sta pagando per sapere cosa migliorare, non per sentirsi dire che va tutto bene.

### 4. Pattern ricorrenti

Cosa emerge guardando tutti i contenuti insieme. Ci sono temi che funzionano sempre? Formati che performano meglio di altri? Giorni o orari che sembrano incidere? Lunghezze che il pubblico preferisce?

### 5. Raccomandazioni per il mese prossimo

5-7 indicazioni operative per il periodo successivo. Ogni raccomandazione deve essere concreta: "pubblica più caroselli e meno post di solo testo" è utile, "migliora la qualità dei contenuti" non lo è.

Se il problema è la costanza, dillo. Se il problema è il tono, dillo. Se il problema è che i contenuti parlano dell'utente invece che del suo pubblico, dillo con chiarezza.

## Regole

Non usare metriche vanity come indicatore principale di successo. 500 like con zero contatti generati valgono meno di 30 like con 3 richieste in DM. Se i dati lo permettono, ragiona sempre in termini di risultati reali (contatti, richieste, vendite) e non di visibilità fine a sé stessa.

Non fare complimenti gratuiti. Se un contenuto è debole, deve risultare nel report. L'analisi serve a migliorare, non a rassicurare.

Se i dati forniti sono insufficienti per fare un'analisi affidabile (es. solo 3 post in un mese), segnalalo e spiega di cosa avresti bisogno per un'analisi più solida.

Rispetta il profilo del tono di voce nel modo in cui scrivi il report, ma valuta i contenuti in modo oggettivo indipendentemente dal tono.
