# Repurposing Contenuti

Questa skill si attiva quando l'utente chiede di trasformare un contenuto esistente in altri formati, o quando usa il comando /riproponi.

## Input

L'utente fornisce un contenuto già scritto: un post LinkedIn, un articolo, una newsletter, un carosello, un'email, una trascrizione di un video o di un podcast. Il contenuto può essere di qualsiasi lunghezza.

## Output

Una serie di contenuti derivati dal materiale originale, adattati per formato e canale. Per ogni contenuto derivato indica il canale, il formato e il testo completo pronto da usare.

### Da un post LinkedIn (input corto)

Produci: 3 storie Instagram (ogni storia una frase chiave del post con un visual diverso), 1 tweet o nota breve per piattaforme a testo corto, 1 spunto per un carosello (la cover e l'angolo, se il tema lo giustifica).

### Da una newsletter (input medio)

Produci: 3-4 post LinkedIn (ognuno sviluppa un singolo concetto dalla newsletter con un angolo diverso), 1 carosello Instagram (10 slide che sintetizzano il contenuto principale), 3-5 storie Instagram, 1 email di rilancio per chi non ha aperto la newsletter.

### Da un articolo o trascrizione lunga (input lungo)

Produci: 5-7 post LinkedIn (ogni post isola un'idea e la sviluppa come contenuto autonomo), 2-3 caroselli Instagram, 1 newsletter che sintetizza i punti chiave, 5-8 storie Instagram, 3-4 spunti per reel o video brevi (script di 30-60 secondi con hook, corpo, chiusura).

## Come adattare tra i formati

Ogni formato ha regole diverse. Non basta accorciare un testo lungo per farne un post corto. Ogni contenuto derivato deve funzionare come se fosse stato pensato per quel canale fin dall'inizio.

Per LinkedIn: apri con un hook che funziona nello scroll di LinkedIn. Tono professionale ma personale. Vai a capo spesso.

Per le storie Instagram: una frase per storia, massimo due. Il testo deve essere leggibile su uno schermo piccolo in 3 secondi. Nessun muro di testo.

Per i caroselli: segui le regole della skill carosello. Ogni slide deve stare in piedi da sola.

Per gli script video: apri con un hook verbale nei primi 3 secondi ("la cosa che nessuno ti dice su..." non è un buon hook. "Ho perso 3 clienti in un mese per questa ragione" lo è). Poi il contenuto, poi la chiusura con CTA.

## Regole

Non ripetere lo stesso testo in formati diversi. Ogni contenuto derivato deve avere un angolo leggermente diverso, anche se parte dallo stesso materiale. Chi segue l'utente su più canali non deve leggere la stessa cosa tre volte.

Non inventare informazioni che non sono nel contenuto originale. Se il post parla di pricing, i derivati parlano di pricing. Non aggiungere concetti che l'utente non ha scritto.

Rispetta il profilo del tono di voce se disponibile.

Indica per ogni contenuto derivato il canale e il formato in modo chiaro, così l'utente può prendere quello che gli serve senza leggere tutto.
