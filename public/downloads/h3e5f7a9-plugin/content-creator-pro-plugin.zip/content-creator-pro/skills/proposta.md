# Proposta Commerciale

Questa skill si attiva quando l'utente chiede di scrivere una proposta per un cliente, un preventivo strutturato, o quando usa il comando /proposta.

## Input

L'utente descrive il progetto: cosa ha chiesto il cliente, che servizio offrirà, quanto vuole farsi pagare, in che tempistiche, e qualsiasi dettaglio rilevante (brief ricevuto, note dalla call conoscitiva, vincoli specifici).

## Output

Un documento di proposta commerciale professionale, pronto da mandare al cliente come PDF o email. Il documento è composto da queste sezioni:

### 1. Contesto

2-3 righe che dimostrano di aver capito la situazione del cliente. Non un riassunto del brief. Una riformulazione che mostra comprensione del problema reale, non solo di quello dichiarato. Il cliente deve leggere questa sezione e pensare "ha capito cosa mi serve".

### 2. Obiettivo del progetto

Cosa si otterrà alla fine del lavoro. Scritto in termini di risultato per il cliente, non in termini di attività che farà l'utente. Non "realizzeremo una strategia di content marketing". Piuttosto "alla fine del progetto avrai un sistema di contenuti che produce 3 contatti qualificati a settimana dal tuo profilo LinkedIn".

### 3. Cosa faremo (scope of work)

Le fasi del progetto, descritte in modo chiaro. Ogni fase ha: cosa include, cosa produce come deliverable, e quanto dura. Il cliente deve capire esattamente cosa riceve e quando.

Non usare gergo tecnico che il cliente non conosce. Se devi usare un termine specifico, spiegalo in una riga.

### 4. Cosa non include

Altrettanto importante dello scope. Indica chiaramente cosa resta fuori dalla proposta. Questo evita malintesi e richieste extra non previste. Sii specifico: "non include la gestione dei canali social" è chiaro, "non include attività non concordate" non lo è.

### 5. Tempistiche

Una timeline realistica con le date chiave. Per ogni fase indica quando inizia, quanto dura, e cosa serve dal cliente per procedere (approvazioni, materiali, accessi).

### 6. Investimento

Il prezzo. Scritto con sicurezza, senza giustificazioni eccessive. Indica cosa include il prezzo, le modalità di pagamento (es. 50% all'avvio, 50% alla consegna), e se ci sono costi aggiuntivi possibili (e in quali circostanze).

Non chiamarlo "investimento" se il contesto non lo richiede. "Costo del progetto" o "compenso" vanno benissimo. Usa il termine che suona naturale nel settore dell'utente.

### 7. Prossimi passi

Cosa deve fare il cliente per procedere. Una sola azione chiara: rispondere all'email, firmare il documento, effettuare il pagamento. Non tre opzioni diverse.

### 8. Validità

Per quanto tempo la proposta resta valida (di solito 15 o 30 giorni). Questo crea un senso di urgenza naturale senza pressione artificiale.

## Regole

Il tono della proposta deve essere professionale senza essere burocratico. Il cliente deve sentirsi in buone mani, non in un ufficio legale.

Non gonfiare la proposta con pagine di presentazione aziendale, mission statement, o elenchi di clienti precedenti. Se l'utente vuole includerli, li mette in un allegato. La proposta parla del progetto del cliente, non dell'ego di chi la scrive.

Non usare template da "proposta tipo" con intestazioni come "Chi siamo", "La nostra vision", "I nostri valori". Il cliente vuole sapere cosa ottiene, quanto costa, e quando lo avrà.

Rispetta il profilo del tono di voce se disponibile.
