# Onboarding Clienti

Questa skill si attiva quando l'utente chiede di creare un questionario di onboarding per i propri clienti, o quando usa il comando /onboarding.

## Input

L'utente fornisce il proprio settore, il tipo di servizio che offre, e il tipo di cliente con cui lavora. Può aggiungere dettagli come la durata tipica di un progetto, i problemi più frequenti con i clienti, o le informazioni che gli servono prima di iniziare.

## Output

Un questionario di onboarding professionale, pronto da mandare al cliente via email o come documento. Il questionario è diviso in sezioni:

### Informazioni generali

Nome, azienda, ruolo, canali di contatto. Le basi, senza domande inutili.

### Obiettivi del progetto

Cosa si aspetta il cliente dal lavoro. Quali risultati considererebbe un successo. In che arco temporale. Questa sezione serve a mettere nero su bianco le aspettative prima che diventino malintesi.

### Contesto e vincoli

Budget (se applicabile). Tempistiche. Risorse già disponibili (testi, immagini, documenti, accessi). Persone coinvolte nella decisione. Eventuali vincoli tecnici, legali, o di brand.

### Preferenze e stile

Come preferisce comunicare (email, call, messaggi). Con che frequenza vuole essere aggiornato. Ha riferimenti visivi o testuali da condividere. Ci sono cose che non vuole assolutamente.

### Domande specifiche del settore

Questa sezione cambia in base al settore dell'utente. Se l'utente è un designer, le domande riguarderanno i riferimenti visivi, il target, i competitor. Se è un consulente di marketing, riguarderanno i canali attivi, gli obiettivi di business, i dati storici. Se è un copywriter, riguarderanno il tono di voce, il pubblico, i contenuti esistenti.

Genera almeno 5 domande specifiche del settore. Ogni domanda deve servire a raccogliere informazioni che evitano problemi dopo.

### Chiusura

Una nota finale che spiega al cliente perché queste domande sono importanti, quanto tempo richiederà compilarle (sii onesto: se sono 15 minuti, scrivi 15 minuti), e cosa succede dopo (es. "Una volta ricevute le risposte, fissiamo la prima call operativa").

## Formato dell'output

Il questionario deve essere pronto da copiare e mandare. Scrivi le domande in modo chiaro, senza gergo tecnico (il cliente potrebbe non conoscerlo). Dopo ogni domanda lascia uno spazio per la risposta.

Il tono del questionario deve essere professionale senza essere freddo. Il cliente deve sentirsi guidato, non interrogato.

## Regole

Rispetta il profilo del tono di voce se disponibile. Il questionario deve sembrare scritto dall'utente, non da un software.

Non aggiungere domande inutili per allungare il questionario. Ogni domanda deve avere un motivo preciso: raccogliere un'informazione che serve per lavorare bene. Se una domanda non cambia il modo in cui lavorerai, toglila.

Non usare scale numeriche ("Da 1 a 10, quanto è importante...") a meno che non servano davvero. Preferisci domande aperte o a scelta tra opzioni concrete.
