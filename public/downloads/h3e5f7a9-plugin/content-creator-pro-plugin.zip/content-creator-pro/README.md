# Content Creator Pro — Plugin Cowork di UseSkill.it

L'ecosistema di marketing completo per professionisti italiani. 12 comandi che coprono tutto il ciclo: dalla strategia alla produzione, dalla distribuzione alla vendita, dalla gestione clienti all'ottimizzazione. Ogni output esce nel tuo tono, pronto da usare.

## Cosa contiene

### Strategia

**/voce** analizza i tuoi testi e costruisce il profilo completo del tuo tono di voce. Tutte le altre skill lo usano come riferimento per calibrare ogni output.

**/strategia** produce un documento di posizionamento: target, problema centrale, messaggio chiave, pilastri di contenuto, analisi competitor e piano d'azione a 30 giorni.

### Produzione contenuti

**/post** scrive un post LinkedIn completo partendo da un'idea, anche vaga. Hook, corpo, chiusura. 40 secondi.

**/newsletter** genera una newsletter completa dai tuoi appunti. Oggetto, apertura, corpo, call to action.

**/carosello** crea 10 slide Instagram con testo calibrato, hook iniziale e chiusura con CTA.

**/calendario** produce un calendario editoriale di 30 giorni con idee concrete, angoli diversi e formati alternati.

### Distribuzione

**/riproponi** prende un contenuto che hai già scritto e lo trasforma in più formati per canali diversi. Da un post LinkedIn escono storie, caroselli, spunti per reel. Da una newsletter escono 4 post. Un contenuto diventa cinque senza pensare da zero.

### Vendita

**/landing** scrive i testi completi per una pagina di vendita o una pagina servizi. Hero, problema, soluzione, benefici, obiezioni, CTA.

**/email** crea sequenze di email commerciali: cold outreach, follow-up dopo una call, riattivazione contatti, vendita dopo un lead magnet. Non una email singola, una sequenza con logica.

**/proposta** genera una proposta commerciale professionale pronta da mandare. Contesto, obiettivo, scope of work, tempistiche, prezzo, prossimi passi.

### Gestione clienti

**/onboarding** genera un questionario professionale per i tuoi clienti, personalizzato per il tuo settore. Le domande giuste, prima della prima call.

### Ottimizzazione

**/analisi** prende i contenuti che hai pubblicato e produce un report con cosa ha funzionato, cosa no, e come migliorare il mese prossimo.

## Come si installa

Apri Claude Desktop e vai nella tab Cowork. In basso a sinistra trovi il menu Plugins. Clicca il "+" e scegli "Upload plugin". Seleziona la cartella content-creator-pro che hai scaricato.

Il plugin si attiva subito. Puoi iniziare a usare i comandi dal primo momento.

## Il percorso consigliato

Il plugin funziona in qualsiasi ordine, ma il percorso che dà i risultati migliori è questo:

Primo passo: lancia /voce e incolla almeno 3 testi che hai scritto tu. Da questo momento ogni output del plugin esce nel tuo stile.

Secondo passo: lancia /strategia per definire il tuo posizionamento, il target e i pilastri di contenuto. Questo dà direzione a tutto quello che produci dopo.

Terzo passo: usa /calendario per pianificare 30 giorni di contenuti basati sulla strategia appena definita.

Da qui in poi produci con /post, /newsletter, /carosello. Moltiplica con /riproponi. Vendi con /landing, /email, /proposta. Gestisci i nuovi clienti con /onboarding. Ogni mese, lancia /analisi per capire cosa migliorare.

## La differenza rispetto alle Skill singole

Le Skill di UseSkill.it funzionano su Claude, Antigravity, Manus e qualsiasi AI compatibile. Sono file singoli che fanno una cosa sola e la fanno bene.

Il plugin Content Creator Pro funziona solo su Claude Cowork (desktop, Mac e Windows) ma fa molto di più: 12 comandi integrati che si parlano tra loro, condividono il contesto del tuo tono di voce, e coprono l'intero ciclo di marketing. Le skill del plugin sono più dettagliate, più specifiche, e ottimizzate per lavorare come sistema.

## Requisiti

Claude Desktop con Cowork attivo. Disponibile su tutti i piani a pagamento (Pro, Max, Team, Enterprise). Funziona su macOS e Windows.

## Supporto

Per qualsiasi problema scrivi a info@useskill.it.
