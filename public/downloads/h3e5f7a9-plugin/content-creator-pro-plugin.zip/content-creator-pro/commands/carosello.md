# /carosello

Crea un carosello Instagram di 10 slide partendo dal concetto fornito dall'utente. Usa la skill carosello per la struttura e le regole. Se il profilo del tono di voce è disponibile nel contesto, applicalo.

Produci tutte le 10 slide complete al primo tentativo, con il testo e la nota sul visual consigliato per ciascuna.

$ARGUMENTS
