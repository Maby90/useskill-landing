# /calendario

Genera un calendario editoriale partendo dal settore, dagli obiettivi e dal periodo indicati dall'utente. Usa la skill calendario per la struttura e le regole. Se il profilo del tono di voce è disponibile nel contesto, applicalo.

Se l'utente non specifica il periodo, genera 30 giorni. Produci il calendario completo al primo tentativo.

$ARGUMENTS
