# /voce

Analizza i testi forniti dall'utente e genera il profilo completo del tono di voce. Usa la skill brand-voice per la struttura e le regole.

L'utente deve fornire almeno 3 testi scritti personalmente. Se ne fornisce meno, chiedi di aggiungerne altri prima di procedere.

$ARGUMENTS
