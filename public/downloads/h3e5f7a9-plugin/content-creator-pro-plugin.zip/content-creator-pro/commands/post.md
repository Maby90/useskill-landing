# /post

Scrivi un post LinkedIn completo partendo dall'idea fornita dall'utente. Usa la skill linkedin-post per la struttura e le regole. Se il profilo del tono di voce è disponibile nel contesto, applicalo a ogni scelta lessicale e strutturale.

Chiedi all'utente solo l'idea. Non chiedere conferme intermedie. Produci il post completo al primo tentativo.

$ARGUMENTS
