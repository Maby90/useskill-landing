# /onboarding

Genera un questionario di onboarding professionale per i clienti dell'utente. Usa la skill onboarding per la struttura e le regole. Chiedi il settore e il tipo di servizio se non sono già nel contesto.

Produci il questionario completo al primo tentativo, pronto da copiare e mandare.

$ARGUMENTS
