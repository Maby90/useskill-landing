# /riproponi

Prendi il contenuto fornito dall'utente e trasformalo in più formati per canali diversi. Usa la skill repurposing per le regole di adattamento tra formati. Ogni contenuto derivato deve funzionare come pezzo autonomo, non come copia accorciata dell'originale.

$ARGUMENTS
