# /newsletter

Scrivi una newsletter completa partendo dagli appunti o dai punti chiave forniti dall'utente. Usa la skill newsletter per la struttura e le regole. Se il profilo del tono di voce è disponibile nel contesto, applicalo.

Produci la newsletter completa (oggetto, apertura, corpo, chiusura con CTA) al primo tentativo.

$ARGUMENTS
