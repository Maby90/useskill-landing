# /landing

Scrivi i testi completi per una pagina di vendita, pagina servizi, o bio professionale. Usa la skill landing per la struttura sezione per sezione. Hero, problema, soluzione, benefici, prova sociale, obiezioni, CTA finale.

Se mancano informazioni per una sezione, segnala cosa serve all'utente.

$ARGUMENTS
