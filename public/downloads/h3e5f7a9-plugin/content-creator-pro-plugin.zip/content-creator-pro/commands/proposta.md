# /proposta

Genera una proposta commerciale professionale partendo dal brief dell'utente. Usa la skill proposta per la struttura: contesto, obiettivo, scope of work, esclusioni, tempistiche, investimento, prossimi passi. Il documento deve essere pronto da mandare al cliente.

$ARGUMENTS
