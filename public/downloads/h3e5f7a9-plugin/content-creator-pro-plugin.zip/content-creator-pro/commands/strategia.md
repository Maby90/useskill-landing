# /strategia

Analizza il posizionamento dell'utente e produci un documento strategico completo: target, problema centrale, posizionamento, messaggio chiave, pilastri di contenuto, analisi competitor e piano d'azione a 30 giorni. Usa la skill strategia per la struttura e le regole.

Se le informazioni fornite sono insufficienti, fai domande mirate prima di procedere.

$ARGUMENTS
