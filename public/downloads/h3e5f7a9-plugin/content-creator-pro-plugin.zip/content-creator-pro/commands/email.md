# /email

Scrivi una sequenza di email commerciali adatta al contesto dell'utente. Usa la skill email-vendita per scegliere il tipo di sequenza (cold outreach, follow-up post call, riattivazione, vendita post lead magnet) e per le regole di scrittura.

Chiedi il contesto se non è chiaro: a chi scrive, cosa vuole ottenere, qual è la relazione attuale con il destinatario.

$ARGUMENTS
