# /analisi

Analizza i contenuti pubblicati dall'utente e produci un report con cosa ha funzionato, cosa no, pattern ricorrenti, e raccomandazioni operative per il mese successivo. Usa la skill analisi per la struttura del report.

Se i dati di performance sono disponibili, usali. Se non lo sono, basa l'analisi sulla qualità del contenuto.

$ARGUMENTS
